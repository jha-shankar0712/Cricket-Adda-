"""
scoreboard.py
-------------
Owns all numeric match state for one innings (runs, wickets, overs,
extras, per-batsman and per-bowler stats) and knows how to render the
in-match HUD (score bar, over indicator, run rate, target/required rate,
mini scorecard). Two Scoreboard instances exist per match, one per innings.
"""

import pygame
from src import constants as C
from src import utils


class BatterStats:
    def __init__(self, name):
        self.name = name
        self.runs = 0
        self.balls = 0
        self.fours = 0
        self.sixes = 0
        self.out = False
        self.how_out = ""

    @property
    def strike_rate(self):
        return round((self.runs / self.balls) * 100, 1) if self.balls else 0.0


class BowlerStats:
    def __init__(self, name):
        self.name = name
        self.balls = 0
        self.runs_conceded = 0
        self.wickets = 0

    @property
    def overs_str(self):
        return f"{self.balls // 6}.{self.balls % 6}"

    @property
    def economy(self):
        overs_frac = self.balls / 6
        return round(self.runs_conceded / overs_frac, 2) if overs_frac else 0.0


class Scoreboard:
    def __init__(self, batting_team, bowling_team, total_overs, target=None):
        self.batting_team = batting_team
        self.bowling_team = bowling_team
        self.total_overs = total_overs
        self.target = target  # None for 1st innings, int for chase

        self.runs = 0
        self.wickets = 0
        self.balls_bowled = 0
        self.extras = {"Wide": 0, "No Ball": 0, "Bye": 0, "Leg Bye": 0}

        self.batters = {}
        self.bowlers = {}
        self.fall_of_wickets = []  # list of (runs, wicket_number, over_str)

        self.powerplay_overs = max(1, int(total_overs * C.POWERPLAY_OVERS_FRACTION))

        self.free_hit_next = False

    # ------------------------------------------------------------------
    def get_batter(self, name):
        if name not in self.batters:
            self.batters[name] = BatterStats(name)
        return self.batters[name]

    def get_bowler(self, name):
        if name not in self.bowlers:
            self.bowlers[name] = BowlerStats(name)
        return self.bowlers[name]

    # ------------------------------------------------------------------
    @property
    def overs_completed(self):
        return self.balls_bowled // 6

    @property
    def balls_this_over(self):
        return self.balls_bowled % 6

    @property
    def overs_str(self):
        return f"{self.overs_completed}.{self.balls_this_over}"

    @property
    def is_powerplay(self):
        return self.overs_completed < self.powerplay_overs

    @property
    def run_rate(self):
        overs_frac = self.balls_bowled / 6
        return round(self.runs / overs_frac, 2) if overs_frac else 0.0

    @property
    def required_run_rate(self):
        if self.target is None:
            return None
        balls_left = self.total_overs * 6 - self.balls_bowled
        runs_needed = self.target - self.runs
        if balls_left <= 0:
            return None
        return round(max(0, runs_needed) / (balls_left / 6), 2)

    @property
    def is_innings_over(self):
        max_wickets = 10
        return (self.wickets >= max_wickets or
                self.balls_bowled >= self.total_overs * 6 or
                (self.target is not None and self.runs >= self.target))

    # ------------------------------------------------------------------
    def add_legal_ball(self, batter_name, bowler_name, runs, is_wicket=False, how_out=""):
        batter = self.get_batter(batter_name)
        bowler = self.get_bowler(bowler_name)

        batter.balls += 1
        batter.runs += runs
        if runs == 4:
            batter.fours += 1
        if runs == 6:
            batter.sixes += 1

        bowler.balls += 1
        bowler.runs_conceded += runs

        self.runs += runs
        self.balls_bowled += 1

        if is_wicket:
            batter.out = True
            batter.how_out = how_out
            self.wickets += 1
            bowler.wickets += 1
            self.fall_of_wickets.append((self.runs, self.wickets, self.overs_str))

    def add_extra(self, extra_type, bowler_name, extra_runs=1, bat_runs=0):
        bowler = self.get_bowler(bowler_name)
        self.runs += extra_runs + bat_runs
        self.extras[extra_type] = self.extras.get(extra_type, 0) + extra_runs
        bowler.runs_conceded += extra_runs + bat_runs
        # Wide and No Ball do not count as a legal delivery
        if extra_type not in ("Wide", "No Ball"):
            self.balls_bowled += 1
            bowler.balls += 1

    # ------------------------------------------------------------------
    def draw_hud(self, surface, screen_w):
        panel_rect = pygame.Rect(20, 16, 380, 92)
        utils.draw_panel(surface, panel_rect)

        utils.draw_text_left(surface, self.batting_team, 18, C.COLOR_WHITE,
                              (panel_rect.left + 14, panel_rect.top + 8), bold=True)
        score_text = f"{self.runs}/{self.wickets}"
        utils.draw_text_left(surface, score_text, 30, C.COLOR_GOLD,
                              (panel_rect.left + 14, panel_rect.top + 30), bold=True)
        over_text = f"Ov {self.overs_str}/{self.total_overs}"
        utils.draw_text_left(surface, over_text, 16, C.COLOR_WHITE,
                              (panel_rect.left + 150, panel_rect.top + 38))
        utils.draw_text_left(surface, f"CRR {self.run_rate}", 15, (200, 220, 255),
                              (panel_rect.left + 14, panel_rect.top + 68))
        if self.target is not None:
            rrr = self.required_run_rate
            need = max(0, self.target - self.runs)
            utils.draw_text_left(surface, f"Need {need} | RRR {rrr}", 15, (255, 210, 150),
                                  (panel_rect.left + 140, panel_rect.top + 68))
        if self.is_powerplay:
            pp_rect = pygame.Rect(panel_rect.right - 96, panel_rect.top + 8, 84, 22)
            utils.draw_panel(surface, pp_rect, color=(255, 195, 0, 210), border=0, radius=6)
            utils.draw_text(surface, "POWERPLAY", 11, C.COLOR_BLACK, pp_rect.center, bold=True, shadow=False)

        # mini scorecard: current batters top-right
        mini_rect = pygame.Rect(screen_w - 300, 16, 280, 90)
        utils.draw_panel(surface, mini_rect)
        y = mini_rect.top + 10
        shown = 0
        for b in self.batters.values():
            if b.out or shown >= 2:
                continue
            line = f"{b.name}  {b.runs} ({b.balls})"
            utils.draw_text_left(surface, line, 15, C.COLOR_WHITE, (mini_rect.left + 12, y))
            y += 22
            shown += 1
        if self.bowlers:
            last_bowler = list(self.bowlers.values())[-1]
            bl = f"{last_bowler.name}  {last_bowler.wickets}-{last_bowler.runs_conceded} ({last_bowler.overs_str})"
            utils.draw_text_left(surface, bl, 14, (200, 230, 200), (mini_rect.left + 12, y + 6))

    def draw_over_indicator(self, surface, x, y, this_over_events):
        """this_over_events: list of strings like '4','W','.','1','Wd' for balls bowled this over."""
        for i in range(6):
            rect = pygame.Rect(x + i * 34, y, 28, 28)
            pygame.draw.rect(surface, (30, 36, 46), rect, border_radius=6)
            pygame.draw.rect(surface, (70, 80, 95), rect, width=1, border_radius=6)
            if i < len(this_over_events):
                label = this_over_events[i]
                color = C.COLOR_WHITE
                if label == "W":
                    color = C.COLOR_RED
                elif label in ("4", "6"):
                    color = C.COLOR_GOLD
                utils.draw_text(surface, label, 15, color, rect.center, bold=True, shadow=False)
