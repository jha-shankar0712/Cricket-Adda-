"""
bat.py
------
Represents the batsman's bat swing: tracks whether a shot has been
triggered this delivery, at what moment (for timing calculation), and
drives a short swing animation angle used by player.py when drawing the
batsman.
"""

import pygame


class Bat:
    def __init__(self):
        self.swinging = False
        self.swing_time = 0.0
        self.swing_duration = 0.28
        self.shot_type = None
        self.triggered_at_ms = None   # ms timestamp (pygame ticks) when Space was pressed
        self.swing_angle = 0.0        # degrees, for drawing

    def trigger(self, shot_type, now_ms):
        if self.swinging:
            return False
        self.swinging = True
        self.swing_time = 0.0
        self.shot_type = shot_type
        self.triggered_at_ms = now_ms
        return True

    def update(self, dt):
        if not self.swinging:
            self.swing_angle = 0.0
            return
        self.swing_time += dt
        t = min(1.0, self.swing_time / self.swing_duration)
        # swing sweeps from -70 deg (backlift) to +50 deg (follow-through)
        self.swing_angle = -70 + 120 * ease_out_back(t)
        if t >= 1.0:
            self.swinging = False

    def reset(self):
        self.swinging = False
        self.swing_time = 0.0
        self.shot_type = None
        self.triggered_at_ms = None
        self.swing_angle = 0.0


def ease_out_back(t):
    c1 = 1.2
    c3 = c1 + 1
    return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2
