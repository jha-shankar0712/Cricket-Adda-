"""
settings.py
-----------
Handles all player-adjustable settings (volume, difficulty, controls,
overs, last-selected teams) and persists them to disk as JSON so they
survive between sessions.
"""

import json
import os
from src import constants as C


class Settings:
    """Holds runtime-adjustable settings and knows how to load/save itself."""

    DEFAULTS = {
        "music_volume": 0.6,
        "sfx_volume": 0.8,
        "difficulty": "Medium",
        "overs": 5,
        "fullscreen": False,
        "team_a": C.DEFAULT_TEAMS[0],
        "team_b": C.DEFAULT_TEAMS[1],
        "player_name": "Player 1",
    }

    def __init__(self):
        # start with a copy of the defaults, then overwrite with saved data
        self.data = dict(Settings.DEFAULTS)
        self.load()

    # ------------------------------------------------------------------
    def load(self):
        """Load settings from disk if the file exists; otherwise keep defaults."""
        if os.path.exists(C.SETTINGS_FILE):
            try:
                with open(C.SETTINGS_FILE, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                self.data.update(saved)
            except (json.JSONDecodeError, OSError):
                # Corrupted or unreadable file - fall back to defaults silently.
                self.data = dict(Settings.DEFAULTS)

    # ------------------------------------------------------------------
    def save(self):
        """Persist current settings to disk, creating the data folder if needed."""
        os.makedirs(os.path.dirname(C.SETTINGS_FILE), exist_ok=True)
        with open(C.SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=4)

    # ------------------------------------------------------------------
    def get(self, key):
        return self.data.get(key, Settings.DEFAULTS.get(key))

    def set(self, key, value):
        self.data[key] = value

    # Convenience typed accessors -----------------------------------
    @property
    def music_volume(self):
        return float(self.data.get("music_volume", 0.6))

    @property
    def sfx_volume(self):
        return float(self.data.get("sfx_volume", 0.8))

    @property
    def difficulty(self):
        return self.data.get("difficulty", "Medium")

    @property
    def overs(self):
        return int(self.data.get("overs", 5))
