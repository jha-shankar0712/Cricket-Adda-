"""
menu.py
-------
Every non-match screen: animated main menu, quick match setup (team /
opponent / overs / difficulty pickers), settings screen (volume sliders,
save), pause overlay, and the match result screen. Each screen exposes
handle_event / update / draw so game.py can drive whichever is active.
"""

import math
import pygame
from src import constants as C
from src import utils


class AnimatedBackground:
    """Slow-drifting colored blobs behind menu screens for a 'modern' feel."""

    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.time = 0.0
        import random
        random.seed(7)
        self.blobs = []
        colors = [(40, 90, 160), (160, 60, 40), (40, 140, 90)]
        for i in range(6):
            self.blobs.append({
                "x": random.uniform(0, width),
                "y": random.uniform(0, height),
                "r": random.uniform(120, 220),
                "speed": random.uniform(8, 20),
                "phase": random.uniform(0, math.tau),
                "color": colors[i % len(colors)],
            })

    def update(self, dt):
        self.time += dt

    def draw(self, surface):
        surface.fill(C.COLOR_BG_DARK)
        blob_surf = pygame.Surface((self.width, self.height), pygame.SRCALPHA)
        for b in self.blobs:
            x = b["x"] + math.sin(self.time * 0.2 + b["phase"]) * 60
            y = b["y"] + math.cos(self.time * 0.15 + b["phase"]) * 40
            pygame.draw.circle(blob_surf, (*b["color"], 35), (int(x), int(y)), int(b["r"]))
        surface.blit(blob_surf, (0, 0))


class MainMenu:
    def __init__(self, screen_w, screen_h, sound_manager, on_select):
        self.bg = AnimatedBackground(screen_w, screen_h)
        self.sound = sound_manager
        self.buttons = []
        labels = [
            ("Quick Match", "quick_match"),
            ("Tournament Mode", "tournament"),
            ("Practice Mode", "practice"),
            ("Settings", "settings"),
            ("Exit", "exit"),
        ]
        start_y = screen_h // 2 - 40
        for i, (label, key) in enumerate(labels):
            rect = pygame.Rect(screen_w // 2 - 160, start_y + i * 68, 320, 54)
            self.buttons.append(utils.Button(rect, label, callback=lambda k=key: on_select(k)))
        self.screen_w = screen_w
        self.screen_h = screen_h

    def handle_event(self, event):
        for b in self.buttons:
            b.handle_event(event, self.sound)

    def update(self, dt):
        self.bg.update(dt)
        mouse = pygame.mouse.get_pos()
        for b in self.buttons:
            b.update(mouse, dt, self.sound)

    def draw(self, surface):
        self.bg.draw(surface)
        utils.draw_text(surface, C.GAME_TITLE, 56, C.COLOR_GOLD,
                         (self.screen_w // 2, 110), bold=True)
        utils.draw_text(surface, "A Modern 2D Cricket Experience", 20, (210, 220, 235),
                         (self.screen_w // 2, 158))
        for b in self.buttons:
            b.draw(surface)
        utils.draw_text(surface, "v1.0 Phase 1", 14, (140, 150, 160),
                         (self.screen_w - 70, self.screen_h - 20), shadow=False)


class SelectorRow:
    """A labelled left/right cycling selector used throughout setup screens."""

    def __init__(self, label, options, rect, index=0):
        self.label = label
        self.options = options
        self.rect = pygame.Rect(rect)
        self.index = index
        left_rect = pygame.Rect(self.rect.left, self.rect.top, 40, self.rect.height)
        right_rect = pygame.Rect(self.rect.right - 40, self.rect.top, 40, self.rect.height)
        self.left_btn = utils.Button(left_rect, "<", font_size=22)
        self.right_btn = utils.Button(right_rect, ">", font_size=22)
        self.left_btn.callback = self.prev
        self.right_btn.callback = self.next

    def prev(self):
        self.index = (self.index - 1) % len(self.options)

    def next(self):
        self.index = (self.index + 1) % len(self.options)

    @property
    def value(self):
        return self.options[self.index]

    def handle_event(self, event, sound=None):
        self.left_btn.handle_event(event, sound)
        self.right_btn.handle_event(event, sound)

    def update(self, mouse, dt, sound=None):
        self.left_btn.update(mouse, dt, sound)
        self.right_btn.update(mouse, dt, sound)

    def draw(self, surface):
        utils.draw_panel(surface, self.rect, color=(24, 30, 40, 210), border=1)
        utils.draw_text_left(surface, self.label, 16, (190, 200, 215),
                              (self.rect.left + 50, self.rect.top + 6))
        utils.draw_text(surface, str(self.value), 20, C.COLOR_WHITE,
                         (self.rect.centerx, self.rect.bottom - 18), bold=True)
        self.left_btn.draw(surface)
        self.right_btn.draw(surface)


class QuickMatchSetup:
    """Choose team, opponent, overs and difficulty, then start the toss."""

    def __init__(self, screen_w, screen_h, settings, sound_manager, on_start, on_back):
        self.screen_w = screen_w
        self.screen_h = screen_h
        self.sound = sound_manager
        self.on_start = on_start
        self.on_back = on_back
        self.bg = AnimatedBackground(screen_w, screen_h)

        cx = screen_w // 2
        rows_top = 220
        row_w, row_h, gap = 420, 56, 18

        teams = C.DEFAULT_TEAMS
        team_idx = teams.index(settings.get("team_a")) if settings.get("team_a") in teams else 0
        opp_idx = teams.index(settings.get("team_b")) if settings.get("team_b") in teams else 1

        self.team_row = SelectorRow("Your Team", teams,
                                     (cx - row_w // 2, rows_top, row_w, row_h), team_idx)
        self.opponent_row = SelectorRow("Opponent", teams,
                                         (cx - row_w // 2, rows_top + (row_h + gap), row_w, row_h), opp_idx)
        overs_idx = C.OVERS_OPTIONS.index(settings.overs) if settings.overs in C.OVERS_OPTIONS else 1
        self.overs_row = SelectorRow("Overs", C.OVERS_OPTIONS,
                                      (cx - row_w // 2, rows_top + 2 * (row_h + gap), row_w, row_h), overs_idx)
        diff_idx = C.DIFFICULTY_OPTIONS.index(settings.difficulty) if settings.difficulty in C.DIFFICULTY_OPTIONS else 1
        self.difficulty_row = SelectorRow("Difficulty", C.DIFFICULTY_OPTIONS,
                                           (cx - row_w // 2, rows_top + 3 * (row_h + gap), row_w, row_h), diff_idx)

        self.rows = [self.team_row, self.opponent_row, self.overs_row, self.difficulty_row]

        start_rect = pygame.Rect(cx - 110, rows_top + 4 * (row_h + gap) + 20, 220, 56)
        self.start_btn = utils.Button(start_rect, "Start Match",
                                       callback=self._start, base_color=(30, 110, 60),
                                       hover_color=(40, 150, 80))
        back_rect = pygame.Rect(30, screen_h - 70, 140, 44)
        self.back_btn = utils.Button(back_rect, "< Back", callback=on_back)

        self.settings = settings

    def _start(self):
        if self.team_row.value == self.opponent_row.value:
            return  # can't play yourself - silently ignore, buttons stay active
        self.settings.set("team_a", self.team_row.value)
        self.settings.set("team_b", self.opponent_row.value)
        self.settings.set("overs", self.overs_row.value)
        self.settings.set("difficulty", self.difficulty_row.value)
        self.settings.save()
        self.on_start(self.team_row.value, self.opponent_row.value,
                      self.overs_row.value, self.difficulty_row.value)

    def handle_event(self, event):
        for r in self.rows:
            r.handle_event(event, self.sound)
        self.start_btn.handle_event(event, self.sound)
        self.back_btn.handle_event(event, self.sound)

    def update(self, dt):
        self.bg.update(dt)
        mouse = pygame.mouse.get_pos()
        for r in self.rows:
            r.update(mouse, dt, self.sound)
        self.start_btn.update(mouse, dt, self.sound)
        self.back_btn.update(mouse, dt, self.sound)

    def draw(self, surface):
        self.bg.draw(surface)
        utils.draw_text(surface, "Quick Match Setup", 40, C.COLOR_GOLD,
                         (self.screen_w // 2, 110), bold=True)
        for r in self.rows:
            r.draw(surface)
        if self.team_row.value == self.opponent_row.value:
            utils.draw_text(surface, "Pick two different teams!", 16, C.COLOR_RED_BAD,
                             (self.screen_w // 2, self.start_btn.rect.top - 16))
        self.start_btn.draw(surface)
        self.back_btn.draw(surface)


class SettingsScreen:
    def __init__(self, screen_w, screen_h, settings, sound_manager, on_back):
        self.screen_w, self.screen_h = screen_w, screen_h
        self.settings = settings
        self.sound = sound_manager
        self.on_back = on_back
        self.bg = AnimatedBackground(screen_w, screen_h)
        self.dragging = None

        cx = screen_w // 2
        self.music_rect = pygame.Rect(cx - 200, 230, 400, 30)
        self.sfx_rect = pygame.Rect(cx - 200, 300, 400, 30)
        back_rect = pygame.Rect(30, screen_h - 70, 140, 44)
        self.back_btn = utils.Button(back_rect, "< Back", callback=self._back)

    def _back(self):
        self.settings.save()
        self.on_back()

    def handle_event(self, event):
        self.back_btn.handle_event(event, self.sound)
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.music_rect.collidepoint(event.pos):
                self.dragging = "music"
            elif self.sfx_rect.collidepoint(event.pos):
                self.dragging = "sfx"
        elif event.type == pygame.MOUSEBUTTONUP:
            self.dragging = None
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            rect = self.music_rect if self.dragging == "music" else self.sfx_rect
            t = utils.clamp((event.pos[0] - rect.left) / rect.width, 0, 1)
            key = "music_volume" if self.dragging == "music" else "sfx_volume"
            self.settings.set(key, round(t, 2))
            if self.dragging == "sfx":
                self.sound.apply_volumes()
            if self.dragging == "music":
                pygame.mixer.music.set_volume(self.settings.music_volume)

    def update(self, dt):
        self.bg.update(dt)
        self.back_btn.update(pygame.mouse.get_pos(), dt, self.sound)

    def _draw_slider(self, surface, rect, value, label):
        utils.draw_text_left(surface, label, 18, C.COLOR_WHITE, (rect.left, rect.top - 28))
        pygame.draw.rect(surface, (40, 46, 58), rect, border_radius=14)
        fill_w = int(rect.width * value)
        fill_rect = pygame.Rect(rect.left, rect.top, fill_w, rect.height)
        pygame.draw.rect(surface, C.COLOR_GOLD, fill_rect, border_radius=14)
        handle_x = rect.left + fill_w
        pygame.draw.circle(surface, C.COLOR_WHITE, (handle_x, rect.centery), 14)
        pygame.draw.circle(surface, C.COLOR_BLACK, (handle_x, rect.centery), 14, 2)
        utils.draw_text(surface, f"{int(value * 100)}%", 14, (200, 210, 225),
                         (rect.right + 40, rect.centery), shadow=False)

    def draw(self, surface):
        self.bg.draw(surface)
        utils.draw_text(surface, "Settings", 42, C.COLOR_GOLD, (self.screen_w // 2, 110), bold=True)
        self._draw_slider(surface, self.music_rect, self.settings.music_volume, "Music Volume")
        self._draw_slider(surface, self.sfx_rect, self.settings.sfx_volume, "SFX Volume")
        self.back_btn.draw(surface)


class PauseMenu:
    def __init__(self, screen_w, screen_h, sound_manager, on_resume, on_quit):
        self.screen_w, self.screen_h = screen_w, screen_h
        self.sound = sound_manager
        cx, cy = screen_w // 2, screen_h // 2
        self.resume_btn = utils.Button((cx - 130, cy - 40, 260, 54), "Resume", callback=on_resume)
        self.quit_btn = utils.Button((cx - 130, cy + 30, 260, 54), "Quit to Menu", callback=on_quit,
                                      base_color=(90, 30, 30), hover_color=(130, 40, 40))

    def handle_event(self, event):
        self.resume_btn.handle_event(event, self.sound)
        self.quit_btn.handle_event(event, self.sound)

    def update(self, dt):
        mouse = pygame.mouse.get_pos()
        self.resume_btn.update(mouse, dt, self.sound)
        self.quit_btn.update(mouse, dt, self.sound)

    def draw(self, surface):
        overlay = pygame.Surface((self.screen_w, self.screen_h), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 160))
        surface.blit(overlay, (0, 0))
        utils.draw_text(surface, "Paused", 44, C.COLOR_WHITE, (self.screen_w // 2, self.screen_h // 2 - 110), bold=True)
        self.resume_btn.draw(surface)
        self.quit_btn.draw(surface)


class ResultScreen:
    def __init__(self, screen_w, screen_h, sound_manager, result_text, summary_lines, on_menu):
        self.screen_w, self.screen_h = screen_w, screen_h
        self.sound = sound_manager
        self.result_text = result_text
        self.summary_lines = summary_lines
        self.bg = AnimatedBackground(screen_w, screen_h)
        cx = screen_w // 2
        self.menu_btn = utils.Button((cx - 130, screen_h - 110, 260, 54), "Main Menu", callback=on_menu)

    def handle_event(self, event):
        self.menu_btn.handle_event(event, self.sound)

    def update(self, dt):
        self.bg.update(dt)
        self.menu_btn.update(pygame.mouse.get_pos(), dt, self.sound)

    def draw(self, surface):
        self.bg.draw(surface)
        utils.draw_text(surface, "MATCH RESULT", 30, (200, 210, 225), (self.screen_w // 2, 110))
        utils.draw_text(surface, self.result_text, 40, C.COLOR_GOLD, (self.screen_w // 2, 160), bold=True)
        panel = pygame.Rect(self.screen_w // 2 - 260, 220, 520, 300)
        utils.draw_panel(surface, panel)
        y = panel.top + 20
        for line in self.summary_lines:
            utils.draw_text_left(surface, line, 18, C.COLOR_WHITE, (panel.left + 24, y))
            y += 30
        self.menu_btn.draw(surface)
