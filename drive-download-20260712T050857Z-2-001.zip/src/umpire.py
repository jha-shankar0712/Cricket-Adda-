"""
umpire.py
---------
Encapsulates rule decisions (wide, no ball, out/not-out) and renders the
umpire figure plus his signal animation (raised finger for OUT, arms out
for WIDE, arm across body for NO BALL).
"""

import random
import pygame
from src import constants as C
from src import utils


class Umpire:
    def __init__(self, x, y):
        self.pos = pygame.Vector2(x, y)
        self.signal = None          # 'OUT' | 'WIDE' | 'NO_BALL' | 'SIX' | None
        self.signal_time = 0.0
        self.signal_duration = 1.4

    # ------------------------------------------------------------------
    def check_wide(self, ball_x, stump_x, wide_margin=55):
        """A delivery pitching/passing too far from the stumps is a wide."""
        return abs(ball_x - stump_x) > wide_margin

    def check_no_ball(self, bowler_front_foot_overstep):
        """bowler_front_foot_overstep: how many px past the crease (0 = legal)."""
        return bowler_front_foot_overstep > 0

    def decide_lbw(self, probability):
        return random.random() < probability

    def raise_signal(self, signal):
        self.signal = signal
        self.signal_time = 0.0

    def update(self, dt):
        if self.signal:
            self.signal_time += dt
            if self.signal_time >= self.signal_duration:
                self.signal = None

    # ------------------------------------------------------------------
    def draw(self, surface):
        x, y = self.pos.x, self.pos.y
        # simple umpire figure: white coat body + hat
        pygame.draw.line(surface, (240, 240, 240), (x, y), (x, y - 40), 10)
        pygame.draw.circle(surface, (245, 210, 180), (int(x), int(y - 48)), 8)
        pygame.draw.polygon(surface, (30, 30, 30), [
            (x - 10, y - 54), (x + 10, y - 54), (x + 12, y - 50), (x - 12, y - 50)
        ])

        arm_l = (x - 14, y - 30)
        arm_r = (x + 14, y - 30)
        if self.signal == "OUT":
            pygame.draw.line(surface, (245, 210, 180), (x, y - 34), (x, y - 70), 5)
            utils.draw_text(surface, "OUT!", 34, C.COLOR_RED, (x, y - 90), bold=True)
        elif self.signal == "WIDE":
            pygame.draw.line(surface, (245, 210, 180), (x, y - 30), arm_l, 5)
            pygame.draw.line(surface, (245, 210, 180), (x, y - 30), arm_r, 5)
            utils.draw_text(surface, "WIDE", 26, C.COLOR_YELLOW, (x, y - 90), bold=True)
        elif self.signal == "NO_BALL":
            pygame.draw.line(surface, (245, 210, 180), (x, y - 30), (x + 16, y - 45), 5)
            utils.draw_text(surface, "NO BALL", 26, C.COLOR_ORANGE_WARN, (x, y - 90), bold=True)
        elif self.signal == "SIX":
            pygame.draw.line(surface, (245, 210, 180), (x, y - 34), (x, y - 74), 5)
            pygame.draw.line(surface, (245, 210, 180), (x, y - 34), (x, y - 74), 5)
            utils.draw_text(surface, "SIX!", 34, C.COLOR_GOLD, (x, y - 90), bold=True)
