"""
physics.py
----------
Pure calculation helpers for ball trajectories, bounce, and shot-outcome
resolution. Kept free of pygame drawing calls so it can be unit-tested
in isolation.
"""

import math
import random
from src import constants as C


def bowl_delivery_duration(speed_kmh, pitch_length_px):
    """
    Convert a bowling speed (km/h) into how many seconds the ball takes
    to travel from the bowler's hand to the batsman, given the pixel
    length of the pitch. Purely a gameplay-feel mapping, not real physics.
    """
    # Map speed range roughly to a duration range: faster ball = less time.
    # 80 km/h -> ~1.15s, 155 km/h -> ~0.55s (tuned for playability)
    t = (speed_kmh - 75) / (160 - 75)
    t = max(0.0, min(1.0, t))
    duration = 1.15 - t * 0.60
    return duration


def swing_offset(bowl_type, seam_or_spin_amount, progress):
    """
    Lateral pixel offset applied to the ball's flight path based on how
    far through its journey it is (0 = release, 1 = reaches bat).
    Swing/seam moves late; spin drifts + turns off the pitch (approximated
    as a smooth curve here since we don't simulate an actual bounce point
    separately in the simplified 2D top-down view).
    """
    if bowl_type == C.BOWL_SPIN:
        curve = math.sin(progress * math.pi) * seam_or_spin_amount
    else:
        # swing bites more in the second half of the flight
        curve = (progress ** 2) * seam_or_spin_amount
    return curve


def resolve_shot_outcome(timing_ms, shot_type, power, difficulty):
    """
    Decide the outcome of a batting attempt.

    timing_ms: signed ms offset between the player's swing and the ideal
               contact moment (0 = perfect, negative = early, positive = late)
    shot_type: one of constants.SHOT_TYPES
    power: 0..1 slider representing how hard the shot was hit
    difficulty: one of constants.DIFFICULTY_OPTIONS - shrinks/grows the
                forgiving timing window

    Returns a dict: {
        'result': 'MISS' | 'DOT' | 'RUNS' | 'BOUNDARY' | 'SIX' | 'CATCH_CHANCE' | 'BOWLED',
        'runs': int,
        'quality': 'perfect' | 'good' | 'edge' | 'miss'
    }
    """
    abs_timing = abs(timing_ms)

    difficulty_scale = {"Easy": 1.4, "Medium": 1.0, "Hard": 0.75, "Expert": 0.55}
    scale = difficulty_scale.get(difficulty, 1.0)
    perfect_window = C.TIMING_PERFECT_MS * scale
    good_window = C.TIMING_GOOD_MS * scale
    miss_window = C.TIMING_EARLY_LATE_MS * scale

    min_r, max_r, risk, six_chance = C.SHOT_PROFILE[shot_type]

    if abs_timing > miss_window:
        # Complete miss - ball goes through to the keeper/stumps.
        # Small chance of being bowled if defensive shot was skipped entirely.
        if shot_type == C.SHOT_DEFENSIVE:
            return {"result": "MISS", "runs": 0, "quality": "miss"}
        bowled_chance = 0.35
        if random.random() < bowled_chance:
            return {"result": "BOWLED", "runs": 0, "quality": "miss"}
        return {"result": "MISS", "runs": 0, "quality": "miss"}

    if abs_timing <= perfect_window:
        quality = "perfect"
        power_mult = 1.0
    elif abs_timing <= good_window:
        quality = "good"
        power_mult = 0.7
    else:
        quality = "edge"
        power_mult = 0.35

    # Edge quality carries a real catch risk regardless of shot type.
    if quality == "edge":
        catch_prob = 0.4 + risk * 0.3
        if random.random() < catch_prob:
            return {"result": "CATCH_CHANCE", "runs": 0, "quality": quality}

    effective_power = power * power_mult

    if quality == "perfect" and random.random() < six_chance * (0.6 + effective_power * 0.6):
        return {"result": "SIX", "runs": 6, "quality": quality}

    runs = min_r + (max_r - min_r) * effective_power
    runs = int(round(runs))
    runs = max(0, min(6, runs))

    if quality != "miss" and runs >= 4 and random.random() < (0.5 + effective_power * 0.5):
        if runs >= 6:
            return {"result": "SIX", "runs": 6, "quality": quality}
        return {"result": "BOUNDARY", "runs": 4, "quality": quality}

    # Non-boundary risk of a catch on lofted/aggressive shots even at good timing
    if quality == "good" and random.random() < risk * 0.5:
        return {"result": "CATCH_CHANCE", "runs": 0, "quality": quality}

    if runs <= 0:
        return {"result": "DOT", "runs": 0, "quality": quality}
    return {"result": "RUNS", "runs": runs, "quality": quality}


def lbw_probability(shot_played, ball_line_offset, difficulty):
    """
    Rough heuristic for whether a missed/defensive shot with the ball
    hitting the pads in front of the stumps should be given LBW.
    ball_line_offset: pixel offset of the ball from the stump line when
                       it reached the batsman (smaller = straighter).
    """
    if shot_played:
        return 0.0
    straightness = max(0.0, 1.0 - abs(ball_line_offset) / 40.0)
    base = 0.5 * straightness
    difficulty_bonus = {"Easy": 0.0, "Medium": 0.05, "Hard": 0.12, "Expert": 0.2}
    return min(0.9, base + difficulty_bonus.get(difficulty, 0.05))
