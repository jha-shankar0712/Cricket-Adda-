"""
utils.py
--------
Small reusable helpers shared across the codebase: math utilities,
font caching, and the Button/UI widgets used by every menu screen.
"""

import math
import pygame
from src import constants as C

_FONT_CACHE = {}


def get_font(size, bold=False):
    """Return a cached pygame Font of the given size (uses default system font)."""
    key = (size, bold)
    if key not in _FONT_CACHE:
        font = pygame.font.SysFont("arial", size, bold=bold)
        _FONT_CACHE[key] = font
    return _FONT_CACHE[key]


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def lerp(a, b, t):
    return a + (b - a) * t


def distance(p1, p2):
    return math.hypot(p1[0] - p2[0], p1[1] - p2[1])


def draw_text(surface, text, size, color, center, bold=False, shadow=True):
    font = get_font(size, bold)
    if shadow:
        shadow_surf = font.render(text, True, (0, 0, 0))
        rect = shadow_surf.get_rect(center=(center[0] + 2, center[1] + 2))
        surface.blit(shadow_surf, rect)
    surf = font.render(text, True, color)
    rect = surf.get_rect(center=center)
    surface.blit(surf, rect)
    return rect


def draw_text_left(surface, text, size, color, topleft, bold=False):
    font = get_font(size, bold)
    surf = font.render(text, True, color)
    surface.blit(surf, topleft)
    return surf.get_rect(topleft=topleft)


def draw_panel(surface, rect, color=C.COLOR_UI_PANEL, border_color=C.COLOR_UI_BORDER, border=2, radius=14):
    panel = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
    pygame.draw.rect(panel, color, panel.get_rect(), border_radius=radius)
    if border > 0:
        pygame.draw.rect(panel, border_color, panel.get_rect(), width=border, border_radius=radius)
    surface.blit(panel, rect.topleft)


class Button:
    """A clickable rectangular UI button with hover/press animation."""

    def __init__(self, rect, text, callback=None, font_size=28, base_color=(35, 45, 60),
                 hover_color=(55, 70, 92), text_color=C.COLOR_WHITE, border_color=C.COLOR_UI_BORDER):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.callback = callback
        self.font_size = font_size
        self.base_color = base_color
        self.hover_color = hover_color
        self.text_color = text_color
        self.border_color = border_color
        self.hovered = False
        self.hover_anim = 0.0  # 0..1 grows toward 1 when hovered
        self.enabled = True
        self._was_hovered = False

    def update(self, mouse_pos, dt, sound_manager=None):
        if not self.enabled:
            self.hovered = False
            return
        self.hovered = self.rect.collidepoint(mouse_pos)
        target = 1.0 if self.hovered else 0.0
        self.hover_anim += (target - self.hover_anim) * min(1.0, dt * 10)
        if self.hovered and not self._was_hovered and sound_manager:
            sound_manager.play("hover")
        self._was_hovered = self.hovered

    def handle_event(self, event, sound_manager=None):
        if not self.enabled:
            return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if sound_manager:
                    sound_manager.play("click")
                if self.callback:
                    self.callback()
                return True
        return False

    def draw(self, surface):
        grow = int(4 * self.hover_anim)
        r = self.rect.inflate(grow, grow)
        color = tuple(
            int(lerp(self.base_color[i], self.hover_color[i], self.hover_anim))
            for i in range(3)
        )
        if not self.enabled:
            color = (40, 40, 40)
        panel = pygame.Surface((r.width, r.height), pygame.SRCALPHA)
        pygame.draw.rect(panel, color, panel.get_rect(), border_radius=10)
        border_alpha = int(120 + 135 * self.hover_anim)
        border_col = (*self.border_color, border_alpha) if len(self.border_color) == 3 else self.border_color
        pygame.draw.rect(panel, border_col, panel.get_rect(), width=2, border_radius=10)
        surface.blit(panel, r.topleft)
        draw_text(surface, self.text, self.font_size,
                  self.text_color if self.enabled else (120, 120, 120), r.center, bold=True)
