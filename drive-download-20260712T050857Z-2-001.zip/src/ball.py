"""
ball.py
-------
The Ball class owns its own position, flight progress, trail history and
drawing. It is deliberately dumb about game rules (overs/wickets/etc.) -
match.py decides what a delivery MEANS, this class only decides where
the ball IS each frame.
"""

import math
import pygame
from src import constants as C
from src import physics


class Ball:
    def __init__(self):
        self.pos = pygame.Vector2(0, 0)
        self.start_pos = pygame.Vector2(0, 0)
        self.end_pos = pygame.Vector2(0, 0)
        self.progress = 0.0          # 0..1 through current flight
        self.duration = 0.9
        self.elapsed = 0.0
        self.trail = []
        self.active = False
        self.bowl_type = C.BOWL_MEDIUM
        self.swing_amount = 0.0
        self.speed_kmh = 120
        self.after_hit = False       # True once bat/miss resolved, ball now travels to outfield
        self.hit_target = pygame.Vector2(0, 0)
        self.hit_duration = 0.0
        self.hit_elapsed = 0.0
        self.radius = 6

    # ------------------------------------------------------------------
    def start_delivery(self, start_pos, end_pos, bowl_type, speed_kmh, swing_amount=18):
        self.pos = pygame.Vector2(start_pos)
        self.start_pos = pygame.Vector2(start_pos)
        self.end_pos = pygame.Vector2(end_pos)
        self.progress = 0.0
        self.elapsed = 0.0
        self.duration = physics.bowl_delivery_duration(
            speed_kmh, self.start_pos.distance_to(self.end_pos)
        )
        self.bowl_type = bowl_type
        self.speed_kmh = speed_kmh
        self.swing_amount = swing_amount
        self.trail = []
        self.active = True
        self.after_hit = False

    def send_after_hit(self, target_pos, duration=0.6):
        """Once the batsman connects, redirect the ball toward the field."""
        self.after_hit = True
        self.hit_elapsed = 0.0
        self.hit_duration = max(0.05, duration)
        self.hit_target = pygame.Vector2(target_pos)
        self.start_pos = pygame.Vector2(self.pos)

    def stop(self):
        self.active = False
        self.trail = []

    # ------------------------------------------------------------------
    def update(self, dt):
        if not self.active:
            return
        if not self.after_hit:
            self.elapsed += dt
            self.progress = min(1.0, self.elapsed / self.duration)
            base = self.start_pos.lerp(self.end_pos, self.progress)
            lateral = physics.swing_offset(self.bowl_type, self.swing_amount, self.progress)
            self.pos = pygame.Vector2(base.x + lateral, base.y)
        else:
            self.hit_elapsed += dt
            t = min(1.0, self.hit_elapsed / self.hit_duration)
            # simple ease-out for a natural deceleration feel
            eased = 1 - (1 - t) ** 2
            self.pos = self.start_pos.lerp(self.hit_target, eased)
            self.progress = 1.0
            if t >= 1.0:
                self.active = False

        self.trail.append(pygame.Vector2(self.pos))
        if len(self.trail) > 14:
            self.trail.pop(0)

    def reached_bat(self):
        return (not self.after_hit) and self.progress >= 1.0

    # ------------------------------------------------------------------
    def draw(self, surface):
        if not self.trail:
            return
        # ball trail
        n = len(self.trail)
        for i, p in enumerate(self.trail):
            alpha = int(180 * (i + 1) / n)
            size = max(1, int(self.radius * 0.5 * (i + 1) / n))
            trail_surf = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
            pygame.draw.circle(trail_surf, (255, 240, 180, alpha), (size, size), size)
            surface.blit(trail_surf, (p.x - size, p.y - size))

        # ball shadow
        pygame.draw.ellipse(
            surface, (0, 0, 0, 90),
            pygame.Rect(int(self.pos.x - self.radius), int(self.pos.y + self.radius * 0.6),
                        self.radius * 2, self.radius)
        )
        pygame.draw.circle(surface, C.COLOR_BALL, (int(self.pos.x), int(self.pos.y)), self.radius)
        pygame.draw.circle(surface, C.COLOR_WHITE, (int(self.pos.x), int(self.pos.y)), self.radius, 1)
