"""
match.py
--------
The heart of gameplay: runs one full match (toss -> innings 1 -> innings
break -> innings 2 -> result). Handles whichever side the human is
currently on (batting controls vs bowling controls) each ball, and lets
the AI modules take over the other side automatically.

Ball-by-ball state machine (self.phase):
    TOSS_ANIM -> BETWEEN_BALLS -> BOWLER_RUNUP -> BALL_FLIGHT ->
    SHOT_WINDOW (human batting) -> RESULT_ANIM -> BETWEEN_BALLS -> ...
    (AI batting skips SHOT_WINDOW and resolves automatically)
"""

import random
import math
import pygame
from src import constants as C
from src import utils
from src import physics
from src import ball as ball_mod
from src import bat as bat_mod
from src import player as player_mod
from src import umpire as umpire_mod
from src import stadium as stadium_mod
from src import scoreboard as sb_mod
from src import ai as ai_mod
from src import animation as anim_mod
from src import camera as camera_mod


BOWL_KEYS = {pygame.K_1: C.BOWL_FAST, pygame.K_2: C.BOWL_MEDIUM, pygame.K_3: C.BOWL_SPIN}
SHOT_KEYS = {
    pygame.K_1: C.SHOT_DEFENSIVE,
    pygame.K_2: C.SHOT_STRAIGHT_DRIVE,
    pygame.K_3: C.SHOT_COVER_DRIVE,
    pygame.K_4: C.SHOT_PULL,
    pygame.K_5: C.SHOT_SWEEP,
    pygame.K_6: C.SHOT_CUT,
    pygame.K_7: C.SHOT_LOFTED,
}


class Match:
    def __init__(self, screen_w, screen_h, sound_manager, settings,
                 team_a, team_b, overs, difficulty, human_bats_first=None):
        self.screen_w, self.screen_h = screen_w, screen_h
        self.sound = sound_manager
        self.settings = settings
        self.team_a = team_a       # human's chosen team
        self.team_b = team_b       # opponent
        self.overs = overs
        self.difficulty = difficulty

        self.stadium = stadium_mod.Stadium(screen_w, screen_h)
        self.camera = camera_mod.Camera(screen_w, screen_h)
        self.particles = anim_mod.ParticleSystem()
        self.ball = ball_mod.Ball()
        self.bat = bat_mod.Bat()
        self.umpire = umpire_mod.Umpire(self.stadium.field_center.x + 60, self.stadium.pitch_top - 10)

        self.bowling_ai = ai_mod.BowlingAI(difficulty)
        self.batting_ai = ai_mod.BattingAI(difficulty)
        self.field_ai = ai_mod.FieldPlacementAI()

        pitch_x = self.stadium.field_center.x
        self.batsman = player_mod.Batsman("Striker", C.COLOR_TEAM_A, pitch_x, self.stadium.pitch_top)
        self.bowler = player_mod.Bowler("Bowler", C.COLOR_TEAM_B, pitch_x, self.stadium.pitch_bottom,
                                        run_start_x=pitch_x - 20)
        self.fielders = self._make_fielders()

        # Toss
        self.toss_winner = None      # 'human' | 'ai'
        self.toss_choice = None      # 'Bat' | 'Bowl'
        self.toss_result_text = ""

        # Innings tracking
        self.innings_number = 1
        self.scoreboards = []
        self.current_scoreboard = None
        self.batting_side_is_human = None  # True if human team currently batting

        self.phase = "TOSS_ANIM"
        self.phase_time = 0.0
        self.between_balls_delay = 1.1

        self.pending_delivery = None
        self.this_over_events = []
        self.last_result = None
        self.match_over = False
        self.winner_text = ""
        self.summary_lines = []

        self.free_hit = False

        self.paused_callback = None
        self.notification = ""
        self.notification_time = 0.0

    # ------------------------------------------------------------------
    def _make_fielders(self):
        positions = self.field_ai.choose_positions(True, 6)
        fielders = []
        cx, cy = self.stadium.field_center.x, self.stadium.field_center.y
        for i, name in enumerate(positions):
            angle = (i / len(positions)) * math.tau
            radius_x = self.stadium.field_radius_x * random.uniform(0.45, 0.85)
            radius_y = self.stadium.field_radius_y * random.uniform(0.45, 0.85)
            x = cx + math.cos(angle) * radius_x
            y = cy + math.sin(angle) * radius_y
            fielders.append(player_mod.Fielder(f"Fielder {i+1}", C.COLOR_TEAM_B, x, y, name))
        return fielders

    # ------------------------------------------------------------------
    def do_toss(self, human_call):
        """human_call: 'Heads' or 'Tails'. Returns nothing, sets toss state."""
        coin = random.choice(["Heads", "Tails"])
        self.toss_winner = "human" if coin == human_call else "ai"
        if self.toss_winner == "ai":
            self.toss_choice = random.choice(["Bat", "Bowl"])
        self.toss_result_text = f"Coin shows {coin}! {'You win' if self.toss_winner == 'human' else self.team_b + ' wins'} the toss."

    def set_human_choice(self, choice):
        """choice: 'Bat' or 'Bowl' - only called if human won the toss."""
        self.toss_choice = choice
        self._start_first_innings()

    def confirm_ai_choice_and_start(self):
        self._start_first_innings()

    def _start_first_innings(self):
        human_bats_first = (
            (self.toss_winner == "human" and self.toss_choice == "Bat") or
            (self.toss_winner == "ai" and self.toss_choice == "Bowl")
        )
        self.batting_side_is_human = human_bats_first
        batting_team = self.team_a if human_bats_first else self.team_b
        bowling_team = self.team_b if human_bats_first else self.team_a
        self.current_scoreboard = sb_mod.Scoreboard(batting_team, bowling_team, self.overs)
        self.scoreboards.append(self.current_scoreboard)
        self.phase = "BETWEEN_BALLS"
        self.phase_time = 0.0
        self.this_over_events = []
        self._notify(f"{batting_team} bat first!")

    def _start_second_innings(self):
        self.innings_number = 2
        prev = self.scoreboards[0]
        target = prev.runs + 1
        self.batting_side_is_human = not self.batting_side_is_human
        batting_team = self.team_a if self.batting_side_is_human else self.team_b
        bowling_team = self.team_b if self.batting_side_is_human else self.team_a
        self.current_scoreboard = sb_mod.Scoreboard(batting_team, bowling_team, self.overs, target=target)
        self.scoreboards.append(self.current_scoreboard)
        self.phase = "BETWEEN_BALLS"
        self.phase_time = 0.0
        self.this_over_events = []
        self._notify(f"{batting_team} need {target} to win!")

    def _notify(self, text):
        self.notification = text
        self.notification_time = 2.2

    # ------------------------------------------------------------------
    def _human_is_bowling(self):
        return not self.batting_side_is_human

    def _current_batter_name(self):
        return "You" if self.batting_side_is_human else "AI Batsman"

    def _current_bowler_name(self):
        return "AI Bowler" if self.batting_side_is_human else "You"

    # ------------------------------------------------------------------
    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return

        if self.phase == "BETWEEN_BALLS" and self._human_is_bowling():
            if event.key in BOWL_KEYS:
                self.pending_delivery = {"bowl_type": BOWL_KEYS[event.key]}
                self._notify(f"Delivery set: {BOWL_KEYS[event.key]}")

        if self.phase == "BOWLER_CHARGE" and self._human_is_bowling():
            if event.key == pygame.K_SPACE:
                self._release_human_delivery()

        if self.phase == "SHOT_WINDOW" and self.batting_side_is_human:
            if event.key in SHOT_KEYS:
                now = pygame.time.get_ticks()
                self.bat.trigger(SHOT_KEYS[event.key], now)

    def handle_continuous_keys(self, keys, dt):
        if self.phase == "SHOT_WINDOW" and self.batting_side_is_human:
            self.batsman.handle_movement(
                keys, dt,
                self.stadium.field_center.x - 40, self.stadium.field_center.x + 40
            )

    # ------------------------------------------------------------------
    def start_over_bowler_runup(self):
        bowl_choice = self.pending_delivery or {"bowl_type": C.BOWL_MEDIUM}
        if self._human_is_bowling():
            self.phase = "BOWLER_CHARGE"
            self.phase_time = 0.0
            self.charge_value = 0.0
            self.charge_dir = 1
            self.pending_bowl_type = bowl_choice["bowl_type"]
        else:
            params = self.bowling_ai.choose_delivery(
                self.current_scoreboard.overs_completed,
                self.current_scoreboard.is_powerplay,
            )
            self._begin_delivery(params)

    def _release_human_delivery(self):
        # charge_value 0..1 represents timing quality of the release (accuracy meter)
        accuracy = 1.0 - abs(self.charge_value - 0.5) * 2  # closer to center (0.5) = better
        bowl_type = self.pending_bowl_type
        lo, hi = C.BOWLING_SPEED_RANGE[bowl_type]
        speed = lo + (hi - lo) * accuracy
        swing_amount = 10 + (1 - accuracy) * 30
        line_offset = (1 - accuracy) * random.choice([-1, 1]) * 45
        params = {
            "bowl_type": bowl_type, "speed": speed,
            "swing_amount": swing_amount, "line_offset": line_offset,
        }
        self._begin_delivery(params)

    def _begin_delivery(self, params):
        self.bowler.start_runup()
        self.current_params = params
        self.phase = "RUNUP_ANIM"
        self.phase_time = 0.0

    # ------------------------------------------------------------------
    def _spawn_ball(self):
        params = self.current_params
        start = pygame.Vector2(self.stadium.field_center.x, self.stadium.pitch_bottom)
        target_x = self.stadium.field_center.x + params["line_offset"]
        end = pygame.Vector2(target_x, self.stadium.pitch_top)
        self.ball.start_delivery(start, end, params["bowl_type"], params["speed"], params["swing_amount"])

        is_wide = self.umpire.check_wide(target_x, self.stadium.field_center.x, wide_margin=55)
        is_no_ball = random.random() < 0.03  # small baseline chance regardless of skill
        self._ball_is_wide = is_wide
        self._ball_is_no_ball = is_no_ball

        if self.batting_side_is_human:
            self.bat.reset()
        self.phase = "BALL_FLIGHT"
        self.phase_time = 0.0

    # ------------------------------------------------------------------
    def update(self, dt, keys):
        self.stadium.update(dt)
        self.camera.update(dt)
        self.particles.update(dt)
        self.umpire.update(dt)
        for f in self.fielders:
            f.update(dt)
        if self.notification_time > 0:
            self.notification_time -= dt

        self.handle_continuous_keys(keys, dt)

        if self.phase == "TOSS_ANIM":
            return  # driven externally by the toss UI in game.py

        elif self.phase == "BETWEEN_BALLS":
            self.phase_time += dt
            if self.phase_time >= self.between_balls_delay:
                self.start_over_bowler_runup()

        elif self.phase == "BOWLER_CHARGE":
            self.phase_time += dt
            self.charge_value += self.charge_dir * dt * 1.3
            if self.charge_value >= 1.0:
                self.charge_value = 1.0
                self.charge_dir = -1
            elif self.charge_value <= 0.0:
                self.charge_value = 0.0
                self.charge_dir = 1

        elif self.phase == "RUNUP_ANIM":
            self.phase_time += dt
            self.bowler.update(dt, self.stadium.field_center.x)
            if self.bowler.state == player_mod.Bowler.IDLE and self.phase_time > 0.3:
                self._spawn_ball()

        elif self.phase == "BALL_FLIGHT":
            self.ball.update(dt)
            self.bat.update(dt)
            if not self.batting_side_is_human:
                # AI batting: decide the moment the ball is roughly halfway,
                # then resolve automatically once it reaches the bat.
                pass
            if self.ball.reached_bat():
                self._on_ball_reached_bat()

        elif self.phase == "SHOT_WINDOW":
            self.bat.update(dt)
            self.phase_time += dt
            if not self.bat.swinging and self.bat.shot_type is not None:
                self._resolve_shot()
            elif self.phase_time > 0.5 and not self.bat.swinging:
                self._resolve_miss()

        elif self.phase == "RESULT_ANIM":
            self.ball.update(dt)
            self.phase_time += dt
            if self.phase_time > 1.1:
                self._finish_ball()

        elif self.phase == "INNINGS_TRANSITION":
            self.phase_time += dt
            if self.phase_time > 2.0:
                self._start_second_innings()

    # ------------------------------------------------------------------
    def _on_ball_reached_bat(self):
        if self._ball_is_wide:
            self._apply_wide()
            return
        if self._ball_is_no_ball:
            self.umpire.raise_signal("NO_BALL")
            self.sound.play("buzzer")
            self.free_hit = True

        if self.batting_side_is_human:
            self.phase = "SHOT_WINDOW"
            self.phase_time = 0.0
            self.shot_window_start_ticks = pygame.time.get_ticks()
        else:
            line_offset = self.ball.pos.x - self.stadium.field_center.x
            shot_type, timing_ms, power = self.batting_ai.choose_shot_and_timing(
                line_offset, self.current_scoreboard.required_run_rate
            )
            self._resolve_shot(ai_timing=timing_ms, ai_shot=shot_type, ai_power=power)

    def _apply_wide(self):
        self.umpire.raise_signal("WIDE")
        self.sound.play("buzzer")
        bowler_name = self._current_bowler_name()
        self.current_scoreboard.add_extra("Wide", bowler_name, extra_runs=1)
        self.this_over_events.append("Wd")
        self.ball.stop()
        self._go_between_balls()

    # ------------------------------------------------------------------
    def _resolve_shot(self, ai_timing=None, ai_shot=None, ai_power=None):
        if ai_timing is not None:
            timing_ms = ai_timing
            shot_type = ai_shot
            power = ai_power
        else:
            # timing_ms: how many ms after the ball reached the bat the player pressed
            # their shot key. Negative = early, 0 = perfect, positive = late.
            if self.bat.triggered_at_ms is not None:
                timing_ms = self.bat.triggered_at_ms - self.shot_window_start_ticks
            else:
                timing_ms = 9999  # no key pressed at all -> guaranteed miss/bowled
            shot_type = self.bat.shot_type or C.SHOT_DEFENSIVE
            power = 0.8

        outcome = physics.resolve_shot_outcome(timing_ms, shot_type, power, self.difficulty)
        self.last_result = outcome
        self._apply_outcome(outcome, shot_type)

    def _resolve_miss(self):
        outcome = {"result": "MISS", "runs": 0, "quality": "miss"}
        self.last_result = outcome
        self._apply_outcome(outcome, C.SHOT_DEFENSIVE)

    def _apply_outcome(self, outcome, shot_type):
        batter_name = self._current_batter_name()
        bowler_name = self._current_bowler_name()
        result = outcome["result"]
        runs = outcome["runs"]

        contact_point = pygame.Vector2(self.ball.pos)
        target = contact_point + pygame.Vector2(random.uniform(-160, 160), -random.uniform(120, 260))
        if result in ("SIX", "BOUNDARY"):
            target = contact_point + pygame.Vector2(random.uniform(-260, 260), -random.uniform(260, 380))
        self.ball.send_after_hit(target, duration=0.7 if result != "MISS" else 0.3)

        no_ball = self._ball_is_no_ball
        # On a no-ball the batsman cannot be dismissed bowled/caught (run-out still could be,
        # but run-outs aren't modelled in this simplified phase-1 build).
        is_wicket_immune = no_ball and result in ("BOWLED", "CATCH_CHANCE")

        def record(runs_scored, is_wicket=False, how_out=""):
            """Route the ball through the scoreboard correctly whether or not it's a no-ball."""
            if no_ball:
                # No-ball: 1 penalty run + whatever the bat scored, and it does NOT
                # count toward the over (bowler must re-bowl it).
                self.current_scoreboard.add_extra("No Ball", bowler_name, extra_runs=1, bat_runs=runs_scored)
            else:
                self.current_scoreboard.add_legal_ball(batter_name, bowler_name, runs_scored,
                                                        is_wicket, how_out)

        if result == "MISS":
            self.sound.play("bat_hit")
            record(0)
            self.this_over_events.append(".")

        elif result == "BOWLED":
            self.sound.play("out")
            if is_wicket_immune:
                record(0)
                self.this_over_events.append(".")
                self._notify("No ball - not out!")
            else:
                self.umpire.raise_signal("OUT")
                record(0, True, C.OUT_BOWLED)
                self.this_over_events.append("W")
                self._notify(f"OUT! {batter_name} bowled!")

        elif result == "CATCH_CHANCE":
            self.sound.play("appeal")
            caught = random.random() < (0.75 if self.difficulty in ("Hard", "Expert") else 0.55)
            if caught and not is_wicket_immune:
                self.sound.play("out")
                self.umpire.raise_signal("OUT")
                record(0, True, C.OUT_CAUGHT)
                self.this_over_events.append("W")
                nearest = min(self.fielders, key=lambda f: f.pos.distance_to(contact_point))
                nearest.dive((contact_point - nearest.pos))
                self._notify(f"CAUGHT! {batter_name} out!")
            else:
                record(1)
                self.this_over_events.append("1")
                self._notify("Dropped! Just one run.")

        elif result == "SIX":
            self.sound.play("six")
            self.camera.shake(14, 0.35)
            self.particles.celebration(contact_point.x, contact_point.y)
            record(6)
            self.this_over_events.append("6")
            self.umpire.raise_signal("SIX")
            self._notify("SIX!")

        elif result == "BOUNDARY":
            self.sound.play("boundary")
            self.particles.burst(contact_point.x, contact_point.y, count=16, color=C.COLOR_GOLD)
            record(4)
            self.this_over_events.append("4")
            self._notify("FOUR!")

        else:  # RUNS / DOT
            self.sound.play("bat_hit")
            record(runs)
            self.this_over_events.append(str(runs) if runs > 0 else ".")
            nearest = min(self.fielders, key=lambda f: f.pos.distance_to(target))
            nearest.chase(target)

        self.free_hit = False
        self.pending_delivery = None
        self.phase = "RESULT_ANIM"
        self.phase_time = 0.0

    # ------------------------------------------------------------------
    def _finish_ball(self):
        if self.current_scoreboard.is_innings_over:
            self._end_innings()
            return
        if self.current_scoreboard.balls_this_over == 0 and self.current_scoreboard.balls_bowled > 0:
            self.this_over_events = []
        self._go_between_balls()

    def _go_between_balls(self):
        self.phase = "BETWEEN_BALLS"
        self.phase_time = 0.0

    def _end_innings(self):
        if self.innings_number == 1:
            self.phase = "INNINGS_TRANSITION"
            self.phase_time = 0.0
        else:
            self._finish_match()

    def _finish_match(self):
        self.match_over = True
        first, second = self.scoreboards[0], self.scoreboards[1]
        if second.runs >= (first.runs + 1):
            wickets_left = 10 - second.wickets
            self.winner_text = f"{second.batting_team} win by {wickets_left} wicket(s)!"
        elif second.runs == first.runs:
            self.winner_text = "Match Tied!"
        else:
            margin = first.runs - second.runs
            self.winner_text = f"{first.batting_team} win by {margin} run(s)!"

        self.summary_lines = [
            f"{first.batting_team}: {first.runs}/{first.wickets} ({first.overs_str} ov)",
            f"{second.batting_team}: {second.runs}/{second.wickets} ({second.overs_str} ov)",
            "",
            "Top Performers:",
        ]
        all_batters = list(first.batters.values()) + list(second.batters.values())
        if all_batters:
            best_bat = max(all_batters, key=lambda b: b.runs)
            self.summary_lines.append(
                f"  {best_bat.name}: {best_bat.runs} runs ({best_bat.balls} balls, SR {best_bat.strike_rate})"
            )
        all_bowlers = list(first.bowlers.values()) + list(second.bowlers.values())
        if all_bowlers:
            best_bowl = max(all_bowlers, key=lambda b: b.wickets)
            self.summary_lines.append(
                f"  {best_bowl.name}: {best_bowl.wickets} wkts, {best_bowl.overs_str} ov, Econ {best_bowl.economy}"
            )

    # ------------------------------------------------------------------
    def draw(self, surface):
        self.stadium.draw(surface)

        for f in self.fielders:
            f.draw(surface)
        self.bowler.draw(surface)
        self.batsman.draw(surface, bat_swing_angle=self.bat.swing_angle)
        self.umpire.draw(surface)
        self.ball.draw(surface)
        self.particles.draw(surface)

        self.current_scoreboard.draw_hud(surface, self.screen_w)
        self.current_scoreboard.draw_over_indicator(surface, 20, 118, self.this_over_events)

        self._draw_phase_ui(surface)

        if self.notification_time > 0:
            alpha = min(255, int(255 * min(1.0, self.notification_time)))
            utils.draw_text(surface, self.notification, 26, C.COLOR_WHITE,
                             (self.screen_w // 2, self.screen_h - 60), bold=True)

    def _draw_phase_ui(self, surface):
        if self.phase == "BETWEEN_BALLS" and self._human_is_bowling():
            utils.draw_text(surface, "Press 1=Fast  2=Medium  3=Spin, then SPACE to bowl",
                             18, C.COLOR_WHITE, (self.screen_w // 2, self.screen_h - 30))
        elif self.phase == "BOWLER_CHARGE":
            self._draw_meter(surface, self.charge_value, "Accuracy Meter - press SPACE!")
        elif self.phase == "SHOT_WINDOW" and self.batting_side_is_human:
            utils.draw_text(surface, "1 Defend 2 Straight 3 Cover 4 Pull 5 Sweep 6 Cut 7 Loft",
                             16, C.COLOR_WHITE, (self.screen_w // 2, self.screen_h - 30))

    def _draw_meter(self, surface, value, label):
        bar_rect = pygame.Rect(self.screen_w // 2 - 200, self.screen_h - 60, 400, 26)
        pygame.draw.rect(surface, (30, 34, 44), bar_rect, border_radius=8)
        pygame.draw.rect(surface, C.COLOR_GREEN_GOOD,
                          (bar_rect.left, bar_rect.top, bar_rect.width // 2 - 20, bar_rect.height), border_radius=8)
        marker_x = bar_rect.left + int(value * bar_rect.width)
        pygame.draw.line(surface, C.COLOR_WHITE, (marker_x, bar_rect.top - 6), (marker_x, bar_rect.bottom + 6), 4)
        utils.draw_text(surface, label, 16, C.COLOR_WHITE, (self.screen_w // 2, bar_rect.top - 16))
