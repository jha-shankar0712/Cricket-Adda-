"""
camera.py
---------
A minimal 2D camera used for smooth follow (e.g. easing toward the ball
during a run) and screen-shake impact feedback (big sixes, wickets).
Since the pitch view is mostly fixed, this mainly drives the shake/zoom
"juice" rather than a scrolling world - but the follow logic is generic
and reusable if the stadium view is expanded later.
"""

import random
from src import utils


class Camera:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.offset_x = 0.0
        self.offset_y = 0.0
        self.target_x = 0.0
        self.target_y = 0.0
        self.zoom = 1.0
        self.target_zoom = 1.0
        self.shake_time = 0.0
        self.shake_strength = 0.0

    def follow(self, x, y):
        self.target_x = x
        self.target_y = y

    def set_zoom(self, zoom):
        self.target_zoom = zoom

    def shake(self, strength=10, duration=0.25):
        self.shake_strength = max(self.shake_strength, strength)
        self.shake_time = max(self.shake_time, duration)

    def update(self, dt):
        ease = min(1.0, dt * 6)
        self.offset_x += (self.target_x - self.offset_x) * ease
        self.offset_y += (self.target_y - self.offset_y) * ease
        self.zoom += (self.target_zoom - self.zoom) * min(1.0, dt * 4)
        if self.shake_time > 0:
            self.shake_time -= dt
        else:
            self.shake_strength = 0

    def get_shake_offset(self):
        if self.shake_strength <= 0:
            return 0, 0
        s = self.shake_strength * utils.clamp(self.shake_time / 0.25, 0, 1)
        return random.uniform(-s, s), random.uniform(-s, s)

    def apply(self, point):
        sx, sy = self.get_shake_offset()
        return point[0] - self.offset_x + sx, point[1] - self.offset_y + sy
