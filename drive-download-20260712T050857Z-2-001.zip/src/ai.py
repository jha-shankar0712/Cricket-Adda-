"""
ai.py
-----
All computer-controlled decision-making lives here:
  - BowlingAI: picks delivery type/line/length/speed when the AI is bowling
  - BattingAI: decides shot + timing quality when the AI is batting
  - FieldPlacementAI: chooses fielder positions based on over/situation
  - AdaptiveDifficulty: nudges difficulty based on how the human is doing

Keeping this separate from match.py means difficulty tuning happens in
ONE place.
"""

import random
from src import constants as C


DIFFICULTY_SKILL = {
    "Easy": 0.35,
    "Medium": 0.55,
    "Hard": 0.75,
    "Expert": 0.92,
}


class BowlingAI:
    """Chooses what kind of ball the computer bowler sends down."""

    def __init__(self, difficulty="Medium"):
        self.difficulty = difficulty
        self.skill = DIFFICULTY_SKILL.get(difficulty, 0.55)

    def choose_delivery(self, over_number, is_powerplay, batter_stats=None):
        # Vary bowling type with some situational logic:
        # - Powerplay: more pace to attack early
        # - Later overs: mix in spin/variation to control run rate
        if is_powerplay:
            weights = {C.BOWL_FAST: 0.55, C.BOWL_MEDIUM: 0.35, C.BOWL_SPIN: 0.10}
        else:
            weights = {C.BOWL_FAST: 0.25, C.BOWL_MEDIUM: 0.35, C.BOWL_SPIN: 0.40}

        bowl_type = random.choices(list(weights.keys()), weights=list(weights.values()))[0]
        lo, hi = C.BOWLING_SPEED_RANGE[bowl_type]
        # Higher skill = more consistent speed (less random spread) and closer to top end
        speed = lo + (hi - lo) * (0.4 + 0.5 * self.skill) + random.uniform(-4, 4) * (1.3 - self.skill)
        speed = max(lo, min(hi, speed))

        # swing/seam/turn amount, more at higher skill
        swing_amount = random.uniform(8, 26) * (0.5 + self.skill * 0.7)

        # line offset from stumps: skilled AI bowls straighter / more testing lines
        line_offset = random.uniform(-1, 1) * (40 - 25 * self.skill)

        return {
            "bowl_type": bowl_type,
            "speed": speed,
            "swing_amount": swing_amount,
            "line_offset": line_offset,
        }

    def accuracy_meter_target(self):
        """Ideal 'accuracy' bar position (0-1) the AI aims near, scaled by skill."""
        return 0.5 + 0.4 * self.skill


class BattingAI:
    """Decides how the AI-controlled batsman plays each delivery."""

    def __init__(self, difficulty="Medium"):
        self.difficulty = difficulty
        self.skill = DIFFICULTY_SKILL.get(difficulty, 0.55)

    def choose_shot_and_timing(self, ball_line_offset, required_run_rate=None):
        """
        Returns (shot_type, timing_ms, power) the AI batsman will use.
        Better skill -> timing_ms closer to 0 (perfect) and shot choice
        that matches the line of the ball.
        """
        # Choose shot based roughly on where the ball is arriving
        if abs(ball_line_offset) < 10:
            shot_pool = [C.SHOT_STRAIGHT_DRIVE, C.SHOT_DEFENSIVE, C.SHOT_LOFTED]
        elif ball_line_offset >= 10:
            shot_pool = [C.SHOT_COVER_DRIVE, C.SHOT_CUT, C.SHOT_PULL]
        else:
            shot_pool = [C.SHOT_PULL, C.SHOT_SWEEP, C.SHOT_DEFENSIVE]

        # Under pressure of a high required run rate, favor aggressive shots
        if required_run_rate and required_run_rate > 9:
            shot_pool.append(C.SHOT_LOFTED)
            shot_pool.append(C.SHOT_LOFTED)

        shot_type = random.choice(shot_pool)

        # timing error shrinks as skill grows
        max_error = 220 * (1.0 - self.skill) + 15
        timing_ms = random.uniform(-max_error, max_error)

        power = 0.4 + 0.5 * self.skill + random.uniform(-0.1, 0.1)
        power = max(0.1, min(1.0, power))

        return shot_type, timing_ms, power


class FieldPlacementAI:
    """Chooses named fielding positions depending on match situation."""

    ATTACKING_POSITIONS = ["Slip", "Gully", "Cover", "Mid-Off", "Mid-On", "Short Leg"]
    DEFENSIVE_POSITIONS = ["Point", "Cover", "Mid-Off", "Mid-On", "Square Leg", "Fine Leg",
                            "Third Man", "Long-On", "Long-Off", "Deep Square"]

    def choose_positions(self, is_powerplay, num_fielders=6):
        pool = self.ATTACKING_POSITIONS if is_powerplay else self.DEFENSIVE_POSITIONS
        if len(pool) >= num_fielders:
            return random.sample(pool, num_fielders)
        # not enough unique names - repeat with numbering
        positions = list(pool)
        while len(positions) < num_fielders:
            positions.append(random.choice(pool))
        return positions[:num_fielders]


class AdaptiveDifficulty:
    """
    Optional gentle rubber-banding: if the human is dominating hugely or
    struggling badly, nudge the effective skill slightly to keep matches
    competitive. Only used when the player opts into 'Adaptive' difficulty
    from Settings; otherwise the chosen difficulty is fixed.
    """

    def __init__(self, base_difficulty="Medium"):
        self.base_skill = DIFFICULTY_SKILL.get(base_difficulty, 0.55)
        self.current_skill = self.base_skill

    def update(self, human_run_rate, ai_expected_rate=7.0):
        diff = human_run_rate - ai_expected_rate
        adjustment = max(-0.15, min(0.15, diff * 0.01))
        self.current_skill = max(0.2, min(0.95, self.base_skill + adjustment))
        return self.current_skill
