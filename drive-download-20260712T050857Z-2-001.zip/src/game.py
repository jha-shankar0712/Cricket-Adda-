"""
game.py
-------
The Game class is the single top-level state machine. main.py creates one
Game instance and calls run(). It owns the screen, clock, settings, sound
manager, and whichever screen/menu/match object is currently active,
switching between them via constants.STATE_* keys.
"""

import sys
import pygame
from src import constants as C
from src import utils
from src.settings import Settings
from src.sound import SoundManager
from src.menu import MainMenu, QuickMatchSetup, SettingsScreen, PauseMenu, ResultScreen, AnimatedBackground
from src.match import Match


class TossScreen:
    """Simple coin-call / bat-or-bowl choice screen shown before a match."""

    def __init__(self, screen_w, screen_h, sound, match_obj, on_done):
        self.screen_w, self.screen_h = screen_w, screen_h
        self.sound = sound
        self.match = match_obj
        self.on_done = on_done
        self.bg = AnimatedBackground(screen_w, screen_h)
        self.stage = "CALL"  # CALL -> RESULT -> CHOICE (if human won) -> DONE
        cx = screen_h // 2
        self.heads_btn = utils.Button((screen_w // 2 - 220, screen_h // 2 + 20, 200, 56), "Heads",
                                       callback=lambda: self._call("Heads"))
        self.tails_btn = utils.Button((screen_w // 2 + 20, screen_h // 2 + 20, 200, 56), "Tails",
                                       callback=lambda: self._call("Tails"))
        self.bat_btn = utils.Button((screen_w // 2 - 220, screen_h // 2 + 20, 200, 56), "Bat First",
                                     callback=lambda: self._choose("Bat"))
        self.bowl_btn = utils.Button((screen_w // 2 + 20, screen_h // 2 + 20, 200, 56), "Bowl First",
                                      callback=lambda: self._choose("Bowl"))
        self.continue_btn = utils.Button((screen_w // 2 - 110, screen_h // 2 + 20, 220, 56), "Continue",
                                          callback=self._continue)
        self.timer = 0.0

    def _call(self, call):
        self.match.do_toss(call)
        self.stage = "RESULT"
        self.timer = 0.0

    def _choose(self, choice):
        self.match.set_human_choice(choice)
        self.stage = "DONE"

    def _continue(self):
        if self.match.toss_winner == "human":
            self.stage = "CHOICE"
        else:
            self.match.confirm_ai_choice_and_start()
            self.stage = "DONE"

    def handle_event(self, event):
        if self.stage == "CALL":
            self.heads_btn.handle_event(event, self.sound)
            self.tails_btn.handle_event(event, self.sound)
        elif self.stage == "RESULT":
            self.continue_btn.handle_event(event, self.sound)
        elif self.stage == "CHOICE":
            self.bat_btn.handle_event(event, self.sound)
            self.bowl_btn.handle_event(event, self.sound)

    def update(self, dt):
        self.bg.update(dt)
        self.timer += dt
        mouse = pygame.mouse.get_pos()
        for b in (self.heads_btn, self.tails_btn, self.bat_btn, self.bowl_btn, self.continue_btn):
            b.update(mouse, dt, self.sound)
        if self.stage == "DONE":
            self.on_done()

    def draw(self, surface):
        self.bg.draw(surface)
        utils.draw_text(surface, "The Toss", 44, C.COLOR_GOLD, (self.screen_w // 2, 140), bold=True)
        if self.stage == "CALL":
            utils.draw_text(surface, "Call it in the air!", 22, C.COLOR_WHITE, (self.screen_w // 2, 220))
            self.heads_btn.draw(surface)
            self.tails_btn.draw(surface)
        elif self.stage == "RESULT":
            utils.draw_text(surface, self.match.toss_result_text, 22, C.COLOR_WHITE, (self.screen_w // 2, 220))
            if self.match.toss_winner == "ai":
                utils.draw_text(surface, f"{self.match.team_b} chooses to {self.match.toss_choice} first.",
                                 20, (220, 220, 220), (self.screen_w // 2, 260))
            self.continue_btn.draw(surface)
        elif self.stage == "CHOICE":
            utils.draw_text(surface, "You won the toss - what will you do?", 22, C.COLOR_WHITE,
                             (self.screen_w // 2, 220))
            self.bat_btn.draw(surface)
            self.bowl_btn.draw(surface)


class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((C.SCREEN_WIDTH, C.SCREEN_HEIGHT))
        pygame.display.set_caption(C.GAME_TITLE)
        self.clock = pygame.time.Clock()
        self.running = True

        self.settings = Settings()
        self.sound = SoundManager(self.settings)

        self.state = C.STATE_MAIN_MENU
        self.active_screen = None
        self.match = None
        self.pause_menu = None
        self.pending_match_setup = None

        self._build_main_menu()

    # ------------------------------------------------------------------
    def _build_main_menu(self):
        self.state = C.STATE_MAIN_MENU
        self.active_screen = MainMenu(C.SCREEN_WIDTH, C.SCREEN_HEIGHT, self.sound, self._on_main_menu_select)

    def _on_main_menu_select(self, key):
        if key == "quick_match":
            self._build_quick_match_setup()
        elif key == "tournament":
            self._build_quick_match_setup(placeholder_note="Tournament Mode reuses Quick Match rules for now.")
        elif key == "practice":
            self._build_quick_match_setup(placeholder_note="Practice Mode: unlimited single-innings batting practice.")
        elif key == "settings":
            self._build_settings()
        elif key == "exit":
            self.running = False

    def _build_quick_match_setup(self, placeholder_note=None):
        self.state = C.STATE_QUICK_MATCH_SETUP
        self.active_screen = QuickMatchSetup(
            C.SCREEN_WIDTH, C.SCREEN_HEIGHT, self.settings, self.sound,
            on_start=self._start_match, on_back=self._build_main_menu
        )

    def _build_settings(self):
        self.state = C.STATE_SETTINGS
        self.active_screen = SettingsScreen(C.SCREEN_WIDTH, C.SCREEN_HEIGHT, self.settings,
                                            self.sound, on_back=self._build_main_menu)

    # ------------------------------------------------------------------
    def _start_match(self, team_a, team_b, overs, difficulty):
        self.match = Match(C.SCREEN_WIDTH, C.SCREEN_HEIGHT, self.sound, self.settings,
                            team_a, team_b, overs, difficulty)
        self.state = C.STATE_TOSS
        self.active_screen = TossScreen(C.SCREEN_WIDTH, C.SCREEN_HEIGHT, self.sound,
                                        self.match, on_done=self._enter_match)

    def _enter_match(self):
        self.state = C.STATE_MATCH
        self.active_screen = None  # match draws itself directly

    def _pause(self):
        if self.state != C.STATE_MATCH:
            return
        self.state = C.STATE_PAUSE
        self.pause_menu = PauseMenu(C.SCREEN_WIDTH, C.SCREEN_HEIGHT, self.sound,
                                     on_resume=self._resume, on_quit=self._quit_to_menu)

    def _resume(self):
        self.state = C.STATE_MATCH

    def _quit_to_menu(self):
        self.match = None
        self._build_main_menu()

    def _show_result(self):
        self.state = C.STATE_RESULT
        self.active_screen = ResultScreen(
            C.SCREEN_WIDTH, C.SCREEN_HEIGHT, self.sound,
            self.match.winner_text, self.match.summary_lines,
            on_menu=self._build_main_menu
        )

    # ------------------------------------------------------------------
    def run(self):
        while self.running:
            dt = self.clock.tick(C.FPS) / 1000.0
            dt = min(dt, 0.05)  # avoid huge jumps if the window was dragged/minimized

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                    if self.state == C.STATE_MATCH:
                        self._pause()
                    elif self.state == C.STATE_PAUSE:
                        self._resume()
                else:
                    self._route_event(event)

            self._update(dt)
            self._draw()
            pygame.display.flip()

        pygame.quit()
        sys.exit()

    # ------------------------------------------------------------------
    def _route_event(self, event):
        if self.state == C.STATE_MATCH and self.match:
            self.match.handle_event(event)
        elif self.state == C.STATE_PAUSE and self.pause_menu:
            self.pause_menu.handle_event(event)
        elif self.active_screen:
            self.active_screen.handle_event(event)

    def _update(self, dt):
        if self.state == C.STATE_MATCH and self.match:
            keys = pygame.key.get_pressed()
            self.match.update(dt, keys)
            if self.match.match_over:
                self._show_result()
        elif self.state == C.STATE_PAUSE and self.pause_menu:
            self.pause_menu.update(dt)
        elif self.active_screen:
            self.active_screen.update(dt)

    def _draw(self):
        if self.state == C.STATE_MATCH and self.match:
            self.match.draw(self.screen)
        elif self.state == C.STATE_PAUSE:
            if self.match:
                self.match.draw(self.screen)
            if self.pause_menu:
                self.pause_menu.draw(self.screen)
        elif self.active_screen:
            self.active_screen.draw(self.screen)
