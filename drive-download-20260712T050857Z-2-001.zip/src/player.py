"""
player.py
---------
All on-field humans (batsman, bowler, fielders) share a common Player
base class. Every player is drawn procedurally with pygame primitives
(circle head, rect body, line limbs) so the game needs no sprite images.
Subclasses add role-specific behaviour: Batsman moves+swings the bat,
Bowler runs up and releases, Fielder chases/dives/throws.
"""

import math
import pygame
from src import constants as C
from src import utils


class Player:
    """Base entity: position, team color, name, simple stats container."""

    def __init__(self, name, team_color, x, y):
        self.name = name
        self.team_color = team_color
        self.pos = pygame.Vector2(x, y)
        self.facing = 1  # 1 = right, -1 = left
        self.height = 46
        self.width = 20

    def draw_body(self, surface, lean=0.0, arm_angle=0.0, leg_spread=0.0, color=None):
        """
        Procedural stick-ish figure: shadow, legs, body rectangle, arm line,
        head circle. `lean` in degrees tilts the torso (e.g. diving),
        `arm_angle` degrees for the bat/throwing arm, `leg_spread` 0..1 for
        running stride.
        """
        col = color or self.team_color
        x, y = self.pos.x, self.pos.y

        # shadow
        shadow_w = self.width * 1.6
        pygame.draw.ellipse(
            surface, (0, 0, 0, 90),
            pygame.Rect(int(x - shadow_w / 2), int(y + 2), int(shadow_w), 8)
        )

        lean_rad = math.radians(lean)
        top = pygame.Vector2(x + math.sin(lean_rad) * self.height * 0.5,
                              y - self.height * 0.9 * math.cos(lean_rad))
        bottom = pygame.Vector2(x, y)

        # legs
        stride = leg_spread * 14
        pygame.draw.line(surface, (30, 30, 30), bottom, (bottom.x - 8 - stride, bottom.y + 2), 5)
        pygame.draw.line(surface, (30, 30, 30), bottom, (bottom.x + 8 + stride, bottom.y + 2), 5)

        # torso
        pygame.draw.line(surface, col, bottom, top, self.width // 2)

        # arm (bat/throw arm)
        arm_rad = math.radians(arm_angle)
        shoulder = top.lerp(bottom, 0.15)
        hand = pygame.Vector2(
            shoulder.x + math.cos(arm_rad) * 28 * self.facing,
            shoulder.y + math.sin(arm_rad) * 28,
        )
        pygame.draw.line(surface, (245, 210, 180), shoulder, hand, 5)

        # head
        head_pos = top + pygame.Vector2(0, -8)
        pygame.draw.circle(surface, (245, 210, 180), (int(head_pos.x), int(head_pos.y)), 9)
        pygame.draw.circle(surface, (20, 20, 20), (int(head_pos.x), int(head_pos.y)), 9, 1)

        return hand  # useful so subclasses can attach a bat/ball sprite at the hand


class Batsman(Player):
    def __init__(self, name, team_color, x, y):
        super().__init__(name, team_color, x, y)
        self.crease_x = x
        self.move_speed = 220
        self.running = False
        self.run_progress = 0.0

    def handle_movement(self, keys, dt, min_x, max_x):
        dx = 0
        if keys[pygame.K_LEFT]:
            dx -= 1
        if keys[pygame.K_RIGHT]:
            dx += 1
        self.pos.x = utils.clamp(self.pos.x + dx * self.move_speed * dt, min_x, max_x)
        if dx != 0:
            self.facing = 1 if dx > 0 else -1

    def draw(self, surface, bat_swing_angle=0.0):
        arm_angle = 20 + bat_swing_angle
        hand = self.draw_body(surface, lean=0, arm_angle=arm_angle)
        # bat blade
        bat_dir = pygame.Vector2(math.cos(math.radians(arm_angle)) * self.facing,
                                  math.sin(math.radians(arm_angle)))
        bat_end = hand + bat_dir * 22
        pygame.draw.line(surface, (200, 160, 100), hand, bat_end, 6)
        pygame.draw.line(surface, (90, 60, 30), hand, bat_end, 2)
        # helmet accent
        pygame.draw.circle(surface, self.team_color,
                            (int(self.pos.x), int(self.pos.y - self.height * 0.98)), 10, 3)


class Bowler(Player):
    RUNUP = "runup"
    DELIVERY = "delivery"
    IDLE = "idle"

    def __init__(self, name, team_color, x, y, run_start_x):
        super().__init__(name, team_color, x, y)
        self.run_start_x = run_start_x
        self.state = Bowler.IDLE
        self.state_time = 0.0
        self.runup_duration = 0.9
        self.delivery_duration = 0.35

    def start_runup(self):
        self.state = Bowler.RUNUP
        self.state_time = 0.0
        self.pos.x = self.run_start_x

    def update(self, dt, target_x):
        if self.state == Bowler.RUNUP:
            self.state_time += dt
            t = min(1.0, self.state_time / self.runup_duration)
            self.pos.x = self.run_start_x + (target_x - self.run_start_x) * t
            if t >= 1.0:
                self.state = Bowler.DELIVERY
                self.state_time = 0.0
        elif self.state == Bowler.DELIVERY:
            self.state_time += dt
            if self.state_time >= self.delivery_duration:
                self.state = Bowler.IDLE

    def is_releasing(self):
        """True on the frame delivery animation should spawn the ball."""
        return self.state == Bowler.DELIVERY and self.state_time < 0.02

    def draw(self, surface):
        if self.state == Bowler.RUNUP:
            leg_spread = 0.7
            arm_angle = -60
        elif self.state == Bowler.DELIVERY:
            t = self.state_time / self.delivery_duration
            leg_spread = 0.2
            arm_angle = -150 + 210 * t
        else:
            leg_spread = 0.0
            arm_angle = -30
        self.draw_body(surface, lean=0, arm_angle=arm_angle, leg_spread=leg_spread)


class Fielder(Player):
    IDLE, CHASING, DIVING, THROWING = "idle", "chasing", "diving", "throwing"

    def __init__(self, name, team_color, x, y, position_name="Cover"):
        super().__init__(name, team_color, x, y)
        self.home = pygame.Vector2(x, y)
        self.state = Fielder.IDLE
        self.speed = 190
        self.state_time = 0.0
        self.position_name = position_name
        self.dive_dir = pygame.Vector2(1, 0)

    def chase(self, target_pos):
        if self.state in (Fielder.DIVING, Fielder.THROWING):
            return
        self.state = Fielder.CHASING
        self._chase_target = pygame.Vector2(target_pos)

    def update(self, dt):
        if self.state == Fielder.CHASING:
            target = getattr(self, "_chase_target", self.home)
            direction = target - self.pos
            dist = direction.length()
            if dist > 4:
                direction = direction.normalize()
                self.pos += direction * self.speed * dt
                self.facing = 1 if direction.x >= 0 else -1
            else:
                self.state = Fielder.IDLE
        elif self.state == Fielder.DIVING:
            self.state_time += dt
            self.pos += self.dive_dir * 260 * dt
            if self.state_time > 0.35:
                self.state = Fielder.IDLE
                self.state_time = 0.0
        elif self.state == Fielder.THROWING:
            self.state_time += dt
            if self.state_time > 0.3:
                self.state = Fielder.IDLE
                self.state_time = 0.0
        elif self.state == Fielder.IDLE:
            # drift back to home position gently
            direction = self.home - self.pos
            if direction.length() > 2:
                self.pos += direction.normalize() * (self.speed * 0.6) * dt

    def dive(self, direction):
        self.state = Fielder.DIVING
        self.state_time = 0.0
        self.dive_dir = pygame.Vector2(direction).normalize() if pygame.Vector2(direction).length() else pygame.Vector2(1, 0)

    def throw(self):
        self.state = Fielder.THROWING
        self.state_time = 0.0

    def draw(self, surface):
        if self.state == Fielder.DIVING:
            lean = 80 * min(1.0, self.state_time / 0.15)
            arm_angle = -40
        elif self.state == Fielder.THROWING:
            arm_angle = -120 + 200 * min(1.0, self.state_time / 0.3)
            lean = 0
        elif self.state == Fielder.CHASING:
            lean = 12
            arm_angle = -20
        else:
            lean = 0
            arm_angle = 10
        leg_spread = 0.6 if self.state == Fielder.CHASING else 0.0
        self.draw_body(surface, lean=lean, arm_angle=arm_angle, leg_spread=leg_spread)
        # small position label
        utils.draw_text(surface, self.position_name, 12, (230, 230, 230),
                         (self.pos.x, self.pos.y + 14), shadow=False)
