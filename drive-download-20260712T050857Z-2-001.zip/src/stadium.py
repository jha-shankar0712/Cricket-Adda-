"""
stadium.py
----------
Draws the whole playing environment: sky gradient, tiered crowd with a
gentle idle animation (simulated "waving" via sine offsets), the outer
boundary rope, the grass field and the pitch strip with crease markings.
Everything is procedural (rects/ellipses/gradients) - no images needed.
"""

import math
import pygame
from src import constants as C


class Stadium:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.time = 0.0
        self.field_center = pygame.Vector2(width // 2, height // 2 + 40)
        self.field_radius_x = width * 0.46
        self.field_radius_y = height * 0.42
        self._sky_cache = self._build_sky_gradient()
        self._crowd_dots = self._build_crowd_dots()

    # ------------------------------------------------------------------
    def _build_sky_gradient(self):
        surf = pygame.Surface((self.width, 160))
        for y in range(160):
            t = y / 160
            color = tuple(
                int(C.COLOR_SKY_TOP[i] + (C.COLOR_SKY_BOTTOM[i] - C.COLOR_SKY_TOP[i]) * t)
                for i in range(3)
            )
            pygame.draw.line(surf, color, (0, y), (self.width, y))
        return surf

    def _build_crowd_dots(self):
        """Precompute crowd seat positions in 3 rings for a stadium bowl look."""
        import random
        random.seed(42)
        dots = []
        colors = [C.COLOR_CROWD_1, C.COLOR_CROWD_2, C.COLOR_CROWD_3]
        for ring in range(3):
            radius_x = self.field_radius_x + 30 + ring * 26
            radius_y = self.field_radius_y + 25 + ring * 22
            count = 90 + ring * 20
            for i in range(count):
                angle = (i / count) * math.tau
                x = self.field_center.x + math.cos(angle) * radius_x
                y = self.field_center.y + math.sin(angle) * radius_y
                if y > self.height - 20:
                    continue
                color = colors[(ring + i) % len(colors)]
                phase = random.uniform(0, math.tau)
                dots.append((x, y, color, phase))
        return dots

    # ------------------------------------------------------------------
    def update(self, dt):
        self.time += dt

    def draw(self, surface):
        surface.fill(C.COLOR_BG_DARK)
        surface.blit(self._sky_cache, (0, 0))

        # crowd (slight bobbing animation per-dot using sine phase)
        for (x, y, color, phase) in self._crowd_dots:
            bob = math.sin(self.time * 3 + phase) * 2
            pygame.draw.circle(surface, color, (int(x), int(y + bob)), 4)

        # outer boundary rope (ellipse ring)
        rope_rect = pygame.Rect(0, 0, int(self.field_radius_x * 2 + 10), int(self.field_radius_y * 2 + 10))
        rope_rect.center = self.field_center
        pygame.draw.ellipse(surface, C.COLOR_BOUNDARY_ROPE, rope_rect, 4)

        # grass field with subtle mowing stripes
        field_rect = pygame.Rect(0, 0, int(self.field_radius_x * 2), int(self.field_radius_y * 2))
        field_rect.center = self.field_center
        field_surf = pygame.Surface(field_rect.size, pygame.SRCALPHA)
        pygame.draw.ellipse(field_surf, C.COLOR_GRASS, field_surf.get_rect())
        stripe_w = 40
        stripe_surf = pygame.Surface(field_rect.size, pygame.SRCALPHA)
        for i, x in enumerate(range(0, field_rect.width, stripe_w)):
            color = C.COLOR_GRASS if i % 2 == 0 else C.COLOR_GRASS_DARK
            pygame.draw.rect(stripe_surf, color, (x, 0, stripe_w, field_rect.height))
        field_surf.blit(stripe_surf, (0, 0), special_flags=pygame.BLEND_RGBA_MULT if False else 0)
        # mask stripes to ellipse shape
        mask = pygame.Surface(field_rect.size, pygame.SRCALPHA)
        pygame.draw.ellipse(mask, (255, 255, 255, 255), mask.get_rect())
        stripe_surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        surface.blit(stripe_surf, field_rect.topleft)

        self.draw_pitch(surface)

    def draw_pitch(self, surface):
        pitch_w = 90
        pitch_h = int(self.field_radius_y * 1.5)
        pitch_rect = pygame.Rect(0, 0, pitch_w, pitch_h)
        pitch_rect.center = self.field_center
        pygame.draw.rect(surface, C.COLOR_PITCH, pitch_rect, border_radius=4)
        pygame.draw.rect(surface, (150, 120, 80), pitch_rect, width=2, border_radius=4)

        # creases (batting + bowling) as white lines near each end
        for offset in (-pitch_h // 2 + 30, pitch_h // 2 - 30):
            y = self.field_center.y + offset
            pygame.draw.line(surface, C.COLOR_PITCH_LINE,
                              (pitch_rect.left + 6, y), (pitch_rect.right - 6, y), 2)

        # stumps at both ends
        self._draw_stumps(surface, self.field_center.x, self.field_center.y - pitch_h // 2 + 14)
        self._draw_stumps(surface, self.field_center.x, self.field_center.y + pitch_h // 2 - 14)

    def _draw_stumps(self, surface, cx, cy):
        for dx in (-8, 0, 8):
            pygame.draw.line(surface, C.COLOR_WHITE, (cx + dx, cy - 16), (cx + dx, cy + 4), 3)
        pygame.draw.line(surface, C.COLOR_WHITE, (cx - 9, cy - 16), (cx + 9, cy - 16), 2)

    @property
    def pitch_top(self):
        pitch_h = int(self.field_radius_y * 1.5)
        return self.field_center.y - pitch_h // 2 + 14

    @property
    def pitch_bottom(self):
        pitch_h = int(self.field_radius_y * 1.5)
        return self.field_center.y + pitch_h // 2 - 14
