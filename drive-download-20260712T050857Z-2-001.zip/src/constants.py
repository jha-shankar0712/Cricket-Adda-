"""
constants.py
------------
Central place for every fixed value used across Ultimate Cricket League.
Nothing in this file changes at runtime - for runtime-adjustable values
(volume, difficulty, overs chosen by the player, etc.) see settings.py.
"""

# ------------------------------------------------------------------
# SCREEN
# ------------------------------------------------------------------
SCREEN_WIDTH = 1280
SCREEN_HEIGHT = 720
FPS = 60
GAME_TITLE = "Ultimate Cricket League"

# ------------------------------------------------------------------
# COLORS (R, G, B)
# ------------------------------------------------------------------
COLOR_BG_DARK = (10, 20, 15)
COLOR_GRASS = (34, 120, 45)
COLOR_GRASS_DARK = (28, 100, 38)
COLOR_PITCH = (196, 164, 108)
COLOR_PITCH_LINE = (235, 230, 210)
COLOR_CROWD_1 = (60, 40, 90)
COLOR_CROWD_2 = (90, 60, 40)
COLOR_CROWD_3 = (40, 70, 90)
COLOR_BOUNDARY_ROPE = (230, 230, 230)
COLOR_WHITE = (255, 255, 255)
COLOR_BLACK = (0, 0, 0)
COLOR_RED = (220, 40, 40)
COLOR_BALL = (170, 20, 20)
COLOR_YELLOW = (255, 205, 40)
COLOR_GOLD = (255, 195, 0)
COLOR_SKY_TOP = (20, 40, 90)
COLOR_SKY_BOTTOM = (90, 140, 190)
COLOR_UI_PANEL = (18, 24, 32, 200)
COLOR_UI_PANEL_LIGHT = (30, 38, 50, 220)
COLOR_UI_BORDER = (255, 195, 0)
COLOR_TEAM_A = (40, 110, 220)
COLOR_TEAM_B = (220, 90, 40)
COLOR_GREEN_GOOD = (60, 200, 90)
COLOR_ORANGE_WARN = (240, 150, 40)
COLOR_RED_BAD = (220, 60, 60)
COLOR_SHADOW = (0, 0, 0, 90)

# ------------------------------------------------------------------
# GAME STATES (state machine keys used by Game class)
# ------------------------------------------------------------------
STATE_LOADING = "LOADING"
STATE_MAIN_MENU = "MAIN_MENU"
STATE_QUICK_MATCH_SETUP = "QUICK_MATCH_SETUP"
STATE_TOURNAMENT_MENU = "TOURNAMENT_MENU"
STATE_PRACTICE_MENU = "PRACTICE_MENU"
STATE_SETTINGS = "SETTINGS"
STATE_TOSS = "TOSS"
STATE_INNINGS_BREAK = "INNINGS_BREAK"
STATE_MATCH = "MATCH"
STATE_PAUSE = "PAUSE"
STATE_RESULT = "RESULT"
STATE_EXIT = "EXIT"

# ------------------------------------------------------------------
# MATCH OPTIONS
# ------------------------------------------------------------------
OVERS_OPTIONS = [2, 5, 10, 20]
DIFFICULTY_OPTIONS = ["Easy", "Medium", "Hard", "Expert"]
BALLS_PER_OVER = 6

# ------------------------------------------------------------------
# BOWLING TYPES
# ------------------------------------------------------------------
BOWL_FAST = "Fast"
BOWL_MEDIUM = "Medium"
BOWL_SPIN = "Spin"
BOWLING_TYPES = [BOWL_FAST, BOWL_MEDIUM, BOWL_SPIN]

BOWLING_SPEED_RANGE = {
    BOWL_FAST: (130, 155),   # km/h
    BOWL_MEDIUM: (105, 130),
    BOWL_SPIN: (75, 100),
}

# ------------------------------------------------------------------
# SHOT TYPES
# ------------------------------------------------------------------
SHOT_DEFENSIVE = "Defensive"
SHOT_STRAIGHT_DRIVE = "Straight Drive"
SHOT_COVER_DRIVE = "Cover Drive"
SHOT_PULL = "Pull Shot"
SHOT_SWEEP = "Sweep Shot"
SHOT_CUT = "Cut Shot"
SHOT_LOFTED = "Lofted Shot"

SHOT_TYPES = [
    SHOT_DEFENSIVE, SHOT_STRAIGHT_DRIVE, SHOT_COVER_DRIVE,
    SHOT_PULL, SHOT_SWEEP, SHOT_CUT, SHOT_LOFTED,
]

# Base run potential / risk per shot: (min_runs, max_runs, risk 0-1, six_chance)
SHOT_PROFILE = {
    SHOT_DEFENSIVE:      (0, 1, 0.02, 0.0),
    SHOT_STRAIGHT_DRIVE: (1, 4, 0.15, 0.05),
    SHOT_COVER_DRIVE:    (1, 4, 0.18, 0.05),
    SHOT_PULL:           (1, 4, 0.25, 0.15),
    SHOT_SWEEP:          (1, 3, 0.20, 0.05),
    SHOT_CUT:            (1, 4, 0.20, 0.05),
    SHOT_LOFTED:         (0, 6, 0.45, 0.55),
}

# ------------------------------------------------------------------
# TIMING WINDOW (milliseconds relative to the ball reaching the bat)
# ------------------------------------------------------------------
TIMING_PERFECT_MS = 40
TIMING_GOOD_MS = 90
TIMING_EARLY_LATE_MS = 160  # beyond this -> miss / edge

# ------------------------------------------------------------------
# DISMISSAL TYPES
# ------------------------------------------------------------------
OUT_BOWLED = "Bowled"
OUT_CAUGHT = "Caught"
OUT_LBW = "LBW"
OUT_RUN_OUT = "Run Out"
OUT_STUMPED = "Stumped"

# ------------------------------------------------------------------
# EXTRAS
# ------------------------------------------------------------------
EXTRA_WIDE = "Wide"
EXTRA_NO_BALL = "No Ball"

# ------------------------------------------------------------------
# POWERPLAY
# ------------------------------------------------------------------
POWERPLAY_OVERS_FRACTION = 0.3  # first 30% of overs are powerplay (min 1)

# ------------------------------------------------------------------
# FILE PATHS
# ------------------------------------------------------------------
SAVE_DIR = "data/save"
SETTINGS_FILE = "data/settings.json"
HIGHSCORE_FILE = "data/highscores.json"
FONT_DIR = "assets/fonts"

# ------------------------------------------------------------------
# TEAMS (default squads - editable, used by Quick Match)
# ------------------------------------------------------------------
DEFAULT_TEAMS = [
    "Mumbai Falcons", "Delhi Warriors", "Chennai Kings",
    "Kolkata Tigers", "Punjab Lions", "Rajasthan Royals XI",
]
