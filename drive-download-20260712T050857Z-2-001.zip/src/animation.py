"""
animation.py
------------
Lightweight particle system (dust on dives, six/four fireworks, edge
sparks) and a generic timed-frame Animator used for player run-cycles,
bowling action, and celebrations. Everything is drawn procedurally with
pygame primitives - no image files required.
"""

import random
import math
import pygame


class Particle:
    __slots__ = ("x", "y", "vx", "vy", "life", "max_life", "color", "size", "gravity")

    def __init__(self, x, y, vx, vy, life, color, size=4, gravity=400):
        self.x = x
        self.y = y
        self.vx = vx
        self.vy = vy
        self.life = life
        self.max_life = life
        self.color = color
        self.size = size
        self.gravity = gravity

    def update(self, dt):
        self.vy += self.gravity * dt
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt
        return self.life > 0

    def draw(self, surface):
        t = max(0.0, self.life / self.max_life)
        alpha = int(255 * t)
        size = max(1, int(self.size * t))
        s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
        pygame.draw.circle(s, (*self.color, alpha), (size, size), size)
        surface.blit(s, (self.x - size, self.y - size))


class ParticleSystem:
    """Owns and updates every active particle in the current scene."""

    def __init__(self):
        self.particles = []

    def burst(self, x, y, count=20, color=(255, 210, 60), speed=250, spread=360,
              life_range=(0.4, 0.9), size=5, gravity=400, direction=270):
        for _ in range(count):
            angle = math.radians(direction + random.uniform(-spread / 2, spread / 2))
            spd = random.uniform(speed * 0.4, speed)
            vx = math.cos(angle) * spd
            vy = math.sin(angle) * spd
            life = random.uniform(*life_range)
            self.particles.append(Particle(x, y, vx, vy, life, color, size, gravity))

    def dust(self, x, y, count=8):
        self.burst(x, y, count=count, color=(190, 170, 120), speed=90,
                    spread=140, life_range=(0.25, 0.5), size=4, gravity=120, direction=270)

    def celebration(self, x, y):
        colors = [(255, 205, 40), (40, 180, 255), (255, 90, 90), (90, 255, 120)]
        for c in colors:
            self.burst(x, y, count=15, color=c, speed=320, spread=360,
                        life_range=(0.6, 1.2), size=6, gravity=250, direction=270)

    def update(self, dt):
        self.particles = [p for p in self.particles if p.update(dt)]

    def draw(self, surface):
        for p in self.particles:
            p.draw(surface)


class Animator:
    """
    Drives a simple state -> phase (0..1 looped or one-shot) value that
    other classes (Player, Ball) sample to pose themselves each frame,
    avoiding the need for sprite-sheets/images.
    """

    def __init__(self):
        self.state = "idle"
        self.time = 0.0
        self.speed = 1.0
        self.loop = True
        self.finished = False

    def play(self, state, speed=1.0, loop=True):
        if self.state != state:
            self.state = state
            self.time = 0.0
        self.speed = speed
        self.loop = loop
        self.finished = False

    def update(self, dt):
        if self.finished and not self.loop:
            return
        self.time += dt * self.speed
        if self.loop:
            self.time %= 1.0
        elif self.time >= 1.0:
            self.time = 1.0
            self.finished = True

    @property
    def phase(self):
        """0..1 progress through the current animation cycle."""
        return self.time if not self.loop else (self.time % 1.0)
