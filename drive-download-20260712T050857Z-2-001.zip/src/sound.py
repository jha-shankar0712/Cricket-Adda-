"""
sound.py
--------
All audio for Ultimate Cricket League is SYNTHESIZED at runtime with numpy
and handed to pygame as Sound objects. This means the game needs zero
external .wav/.mp3 files to run - satisfying "no placeholder assets".

If you later want to swap in real recorded audio, just drop files into
assets/sounds/ and load them with pygame.mixer.Sound(path) instead of the
generator functions below.
"""

import numpy as np
import pygame

SAMPLE_RATE = 44100


def _stereo(mono):
    """Convert a mono float32 array in [-1, 1] to an int16 stereo array."""
    mono = np.clip(mono, -1.0, 1.0)
    pcm = (mono * 32767).astype(np.int16)
    stereo = np.column_stack((pcm, pcm))
    return np.ascontiguousarray(stereo)


def _tone(freq, duration, volume=0.5, wave="sine", fade=True):
    n = int(SAMPLE_RATE * duration)
    t = np.linspace(0, duration, n, endpoint=False)
    if wave == "sine":
        wf = np.sin(2 * np.pi * freq * t)
    elif wave == "square":
        wf = np.sign(np.sin(2 * np.pi * freq * t))
    elif wave == "saw":
        wf = 2 * (t * freq - np.floor(0.5 + t * freq))
    else:
        wf = np.sin(2 * np.pi * freq * t)
    if fade:
        fade_len = max(1, int(n * 0.1))
        env = np.ones(n)
        env[:fade_len] = np.linspace(0, 1, fade_len)
        env[-fade_len:] = np.linspace(1, 0, fade_len)
        wf = wf * env
    return wf * volume


def _noise_burst(duration, volume=0.4):
    n = int(SAMPLE_RATE * duration)
    wf = np.random.uniform(-1, 1, n)
    fade_len = max(1, int(n * 0.15))
    env = np.ones(n)
    env[:fade_len] = np.linspace(0, 1, fade_len)
    env[-fade_len:] = np.linspace(1, 0, fade_len)
    return wf * env * volume


def _mix(*layers):
    max_len = max(len(l) for l in layers)
    out = np.zeros(max_len)
    for l in layers:
        out[: len(l)] += l
    return out


class SoundManager:
    """Generates and plays every sound effect / background loop in the game."""

    def __init__(self, settings):
        self.settings = settings
        self.enabled = True
        try:
            pygame.mixer.init(frequency=SAMPLE_RATE, size=-16, channels=2)
        except pygame.error:
            self.enabled = False
            return
        self.sounds = {}
        self._generate_all()
        self.apply_volumes()

    # ------------------------------------------------------------------
    def _make(self, name, mono_wave):
        arr = _stereo(mono_wave)
        snd = pygame.sndarray.make_sound(arr)
        self.sounds[name] = snd

    def _generate_all(self):
        # Bat hitting ball - short sharp crack (noise burst + high tone)
        bat_hit = _mix(_noise_burst(0.08, 0.6), _tone(900, 0.06, 0.5, "square"))
        self._make("bat_hit", bat_hit)

        # Boundary (four) - rising two-tone chime
        four = _mix(_tone(523, 0.15, 0.35), _tone(659, 0.15, 0.3))
        self._make("boundary", four)

        # Six - bigger rising triad + noise swell
        six = _mix(
            _tone(523, 0.25, 0.3), _tone(659, 0.25, 0.28),
            _tone(784, 0.3, 0.3), _noise_burst(0.3, 0.15),
        )
        self._make("six", six)

        # Wicket / out - low dramatic thud + descending tone
        out_snd = _mix(_tone(180, 0.35, 0.5, "square"), _noise_burst(0.2, 0.3))
        self._make("out", out_snd)

        # Appeal - crowd-like rising noise
        appeal = _noise_burst(0.6, 0.25)
        self._make("appeal", appeal)

        # Cheer - layered noise + tones (crowd cheering)
        cheer = _mix(_noise_burst(0.8, 0.3), _tone(300, 0.8, 0.15))
        self._make("cheer", cheer)

        # Crowd ambience loop - soft filtered noise
        crowd = _noise_burst(2.0, 0.12)
        self._make("crowd", crowd)

        # UI click
        click = _tone(700, 0.05, 0.35, "square", fade=False)
        self._make("click", click)

        # UI hover
        hover = _tone(500, 0.04, 0.2, "sine", fade=False)
        self._make("hover", hover)

        # Wide/No-ball buzzer
        buzz = _tone(220, 0.25, 0.4, "square")
        self._make("buzzer", buzz)

    # ------------------------------------------------------------------
    def apply_volumes(self):
        if not self.enabled:
            return
        sfx_vol = self.settings.sfx_volume
        for snd in self.sounds.values():
            snd.set_volume(sfx_vol)

    def play(self, name, loops=0):
        if not self.enabled or name not in self.sounds:
            return
        self.sounds[name].play(loops=loops)

    def stop(self, name):
        if not self.enabled or name not in self.sounds:
            return
        self.sounds[name].stop()
