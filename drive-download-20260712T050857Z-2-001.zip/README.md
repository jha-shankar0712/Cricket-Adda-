# Ultimate Cricket League (Phase 1)

A 2D cricket game built with Python + Pygame. All graphics are drawn procedurally
(no image files needed) and all sound effects are synthesized in code with numpy
(no audio files needed) — so the game runs immediately with nothing to download
besides the two libraries below.

## Setup (Windows 11 + VS Code)

1. Install Python 3.11+ from python.org (check "Add to PATH" during install).
2. Open the `CricketGame` folder in VS Code.
3. Open a terminal in VS Code (`` Ctrl+` ``) and run:
   ```
   pip install -r requirements.txt
   ```
4. Run the game:
   ```
   python main.py
   ```

## Controls

**Menus:** mouse click on buttons / selector arrows.

**Bowling (when it's your turn to bowl):**
- `1` = Fast, `2` = Medium, `3` = Spin (choose before the delivery starts)
- Hold and watch the accuracy meter, press `SPACE` when the marker is centered
  for the fastest, most accurate ball.

**Batting (when it's your turn to bat):**
- `←` / `→` = shuffle across the crease
- `1` Defensive `2` Straight Drive `3` Cover Drive `4` Pull Shot
  `5` Sweep Shot `6` Cut Shot `7` Lofted Shot
- Press the shot key the instant the ball reaches you — perfect timing
  gets you fours and sixes, mistimed shots risk a catch.

**Anytime:** `ESC` = pause / resume.

## What's implemented in this build (Phase 1)

- Main Menu → Quick Match → Toss → full 2-innings match → Result screen
- Team/opponent/overs(2/5/10/20)/difficulty(Easy/Medium/Hard/Expert) selection
- Toss (call heads/tails, choose bat/bowl)
- Ball-by-ball batting & bowling loop, with the AI automatically playing
  whichever side you are not controlling that innings
- 7 shot types with a timing-window system (perfect/good/edge/miss)
- 3 bowling types (Fast/Medium/Spin) with a speed/accuracy meter
- Wickets: Bowled, Caught, with umpire "OUT" signal
- Extras: Wide (adds run, re-bowled), No Ball (adds run, re-bowled,
  batsman can't be given bowled/caught off it)
- Powerplay indicator, current run rate, target & required run rate
- Live scoreboard, mini-scorecard, over-by-over ball indicator
- Animated stadium (crowd, boundary rope, grass, pitch, stumps), fielders
  with chase/dive animations, ball trail, screen-shake on sixes, particle
  effects for boundaries/celebrations
- Full synthesized sound effects (bat hit, four, six, out, appeal, cheer,
  crowd ambience, UI clicks, wide/no-ball buzzer) and a settings screen with
  music/SFX volume sliders, saved to `data/settings.json`
- Pause menu, Main Menu / Quick Match / Settings navigation, Exit

## Coming in the next iterations (ask and we'll keep building — nothing is final)

- Tournament Mode with a real bracket/points table and Practice Mode with
  session stats (currently both route into Quick Match rules as a stopgap)
- LBW decisions and Run Out / Stumped mechanics with a run-between-wickets
  mini-game
- True "free hit" bonus delivery after a no-ball
- Career/match save-and-load system and persistent high scores
- Man of the Match, full match-summary stat screens
- Background music track (currently only SFX + crowd ambience loop)
- Adaptive difficulty toggle in Settings (the AI module already supports it)

## Project Structure

```
CricketGame/
  assets/            (reserved for future real art/audio; currently unused —
                       everything is generated in code)
  data/
    save/            (reserved for save-game files)
    settings.json    (created automatically on first run)
  src/
    __init__.py
    constants.py     screen/colors/states/gameplay tuning constants
    settings.py      persistent settings (JSON load/save)
    sound.py         synthesizes every sound effect with numpy
    utils.py         fonts, buttons, drawing helpers
    animation.py      particle system + generic animator
    camera.py        screen shake / smooth follow
    physics.py       trajectory + shot-outcome resolution
    ball.py          Ball entity (flight, trail, bounce)
    bat.py           Bat swing/timing tracker
    player.py        Player base class + Batsman, Bowler, Fielder
    umpire.py        Wide/no-ball/LBW logic + umpire signal animation
    stadium.py       Procedural stadium/crowd/pitch rendering
    scoreboard.py    Runs/wickets/overs/extras/stats + HUD drawing
    ai.py            Bowling AI, Batting AI, field placement, adaptive difficulty
    menu.py          Main menu, quick match setup, settings, pause, result screens
    match.py         Ball-by-ball match state machine (the core game loop)
    game.py          Top-level state machine tying every screen together
  main.py            Entry point
  requirements.txt
  README.md
```

## Notes on this build

- I don't have internet access in the environment I built this in, so I
  wasn't able to launch pygame and click through it myself before handing
  it to you. Every file has been syntax-checked and the object/method calls
  cross-checked by hand, but if you hit a runtime error when you first run
  it, paste it back to me — tell me the error, and I'll explain why it
  happened and fix it immediately, then we keep going, exactly as you asked.
