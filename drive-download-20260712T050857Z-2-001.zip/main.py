"""
main.py
-------
Entry point for Ultimate Cricket League.
Run this file from the CricketGame/ folder:

    python main.py

Requirements (see requirements.txt):
    pip install pygame numpy
"""

from src.game import Game


def main():
    game = Game()
    game.run()


if __name__ == "__main__":
    main()
